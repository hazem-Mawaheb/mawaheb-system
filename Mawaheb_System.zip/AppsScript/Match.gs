/** MATCH + SHORTLIST: نفس نظام الـ100 نقطة في match.py (المسمى 15 | المجال 30 | القطاع 20 | المؤهل 10 | كلمات 10 | ERP 10 | الموقع 5) */
var W_TITLE = 15, W_FIELD_KW = 20, W_FIELD_EXP = 10, W_FIELD = 30, W_INDUS = 20, W_EDU = 10, W_KEYS = 10, W_ERP = 10, W_LOC = 5;
var GENERIC_TITLE_WORDS = ['manager', 'senior', 'junior', 'assistant', 'officer', 'specialist', 'executive', 'director', 'head', 'lead', 'supervisor', 'coordinator', 'chief', 'associate', 'مدير', 'مسؤول', 'رئيس', 'مشرف', 'منسق', 'مساعد', 'اخصائي', 'أخصائي'];
var FALLBACK_COLS = ['Education', 'Last Position', 'Target Position', 'Notes'];
var RATING_FILL = { Strong: '#C6EFCE', Good: '#E2EFDA', Possible: '#FFEB9C', Weak: '#F8CBAD' };
var HDR_BG = '#1F4E78';
var TOP_N = 7;

function norm(s) {
  s = String(s || '').toLowerCase().replace(/[أإآ]/g, 'ا').replace(/ة/g, 'ه').replace(/ى/g, 'ي');
  return s.replace(/[^\p{L}\p{N}_\s]/gu, ' ').replace(/\s+/g, ' ').trim();
}
function hasTerm(textNorm, term) {
  var t = norm(term);
  if (!t) return false;
  if (/[\u0600-\u06FF]/.test(t)) return textNorm.indexOf(t) >= 0;
  return (' ' + textNorm + ' ').indexOf(' ' + t + ' ') >= 0;
}
function eduLevel(text) {
  var t = ' ' + norm(text) + ' ';
  if (/phd|ph d|doctorate|doctoral|دكتوراه/.test(t)) return 4;
  if (/master|mba|m sc|msc| ma |ماجستير/.test(t)) return 3;
  if (/bachelor|b sc|bsc|bba| ba |beng|degree|بكالوريوس|جامعي/.test(t)) return 2;
  if (/diploma|associate|دبلوم/.test(t)) return 1;
  return 0;
}
function toNum(v) { var s = String(v == null ? '' : v).replace(/,/g, '').trim(); if (s === '') return null; var n = Number(s); return isNaN(n) ? null : n; }
function fmtNum(n) { return n === Math.floor(n) ? String(n) : n.toFixed(1); }
function parseList(v) { return String(v || '').split(/[,;،\n]/).map(function (x) { return x.trim(); }).filter(String); }

function readJobs() {
  var t = readTable(SH.JOBS), jobs = [];
  t.rows.forEach(function (r) {
    var title = String(r[JOB_COLS[0]] || '').trim();
    if (!title) return;
    var edu = String(r[JOB_COLS[7]] || '').trim();
    jobs.push({
      title: title, field_kws: parseList(r[JOB_COLS[1]]), industry_kws: parseList(r[JOB_COLS[2]]),
      general_kws: parseList(r[JOB_COLS[3]]), erp_kws: parseList(r[JOB_COLS[4]]),
      min_exp: toNum(r[JOB_COLS[5]]), max_exp: toNum(r[JOB_COLS[6]]),
      min_edu: edu ? eduLevel(edu) : 0, location: String(r[JOB_COLS[8]] || '').trim()
    });
  });
  return jobs;
}

function candidateText(c, texts) {
  var t = texts[c['Candidate ID']];
  if (t) return { text: t, full: true };
  return { text: FALLBACK_COLS.map(function (k) { return c[k] || ''; }).join(' '), full: false };
}

function kwPoints(kws, textNorm, weight, boost) {
  var hits = kws.filter(function (k) { return hasTerm(textNorm, k); });
  return { pts: Math.round(weight * Math.min(hits.length / kws.length * boost, 1)), hits: hits };
}

function scoreCandidate(job, c, text) {
  var parts = {}, why = [], textNorm = norm(text);

  var posRaw = c['Last Position'] || c['Target Position'] || '';
  var pos = norm(posRaw), jt = norm(job.title);
  if (!pos) { parts.Title = [0, W_TITLE]; why.push('المسمى غير محدد'); }
  else {
    if (!c['Last Position']) why.push('المسمى من الوظيفة المستهدفة (لا توجد سيرة)');
    if ((' ' + pos + ' ').indexOf(' ' + jt + ' ') >= 0) parts.Title = [W_TITLE, W_TITLE];
    else {
      var jw = jt.split(' '), common = pos.split(' ').filter(function (w) { return jw.indexOf(w) >= 0; });
      var specific = common.filter(function (w) { return GENERIC_TITLE_WORDS.indexOf(w) < 0; });
      if (specific.length) { parts.Title = [10, W_TITLE]; why.push('مسمى قريب أو مستوى مختلف'); }
      else if (common.length) { parts.Title = [3, W_TITLE]; why.push('المسمى يشترك في المستوى فقط وليس في التخصص'); }
      else { parts.Title = [0, W_TITLE]; why.push('المسمى الوظيفي غير مطابق'); }
    }
  }

  var kwp;
  if (job.field_kws.length) { var r1 = kwPoints(job.field_kws, textNorm, W_FIELD_KW, 1.5); kwp = r1.pts; if (!r1.hits.length) why.push('لم تظهر كلمات المجال المطلوبة'); }
  else kwp = W_FIELD_KW;
  var y = toNum(c['Experience (Years)']), expp;
  if (job.min_exp == null) expp = W_FIELD_EXP;
  else if (y == null) { expp = 0; why.push('سنوات الخبرة غير محددة'); }
  else if (y >= job.min_exp) expp = W_FIELD_EXP;
  else { expp = job.min_exp > 0 ? Math.round(W_FIELD_EXP * (y / job.min_exp)) : W_FIELD_EXP; why.push('الخبرة أقل بـ ' + fmtNum(job.min_exp - y) + ' سنوات'); }
  if (job.max_exp != null && y != null && y > job.max_exp) why.push('الخبرة أعلى من الحد الأقصى (' + fmtNum(job.max_exp) + ' سنة)');
  parts['Field Exp'] = [Math.min(kwp + expp, W_FIELD), W_FIELD];

  if (job.industry_kws.length) { var r3 = kwPoints(job.industry_kws, textNorm, W_INDUS, 2.0); parts.Industry = [r3.pts, W_INDUS]; if (!r3.hits.length) why.push('لم تذكر خبرة سابقة في نفس القطاع'); }
  else parts.Industry = [W_INDUS, W_INDUS];

  if (job.min_edu) {
    var lv = eduLevel(c['Education']);
    if (lv === 0) { parts.Education = [0, W_EDU]; why.push('المؤهل غير محدد'); }
    else if (lv >= job.min_edu) parts.Education = [W_EDU, W_EDU];
    else if (lv === job.min_edu - 1) { parts.Education = [5, W_EDU]; why.push('المؤهل أقل بمستوى واحد'); }
    else { parts.Education = [0, W_EDU]; why.push('المؤهل أقل من المطلوب'); }
  } else parts.Education = [W_EDU, W_EDU];

  parts.Keywords = job.general_kws.length ? [kwPoints(job.general_kws, textNorm, W_KEYS, 1.3).pts, W_KEYS] : [W_KEYS, W_KEYS];

  if (job.erp_kws.length) { var r6 = kwPoints(job.erp_kws, textNorm, W_ERP, 1.5); parts.ERP = [r6.pts, W_ERP]; if (!r6.hits.length) why.push('لم تذكر معرفة بأنظمة ERP المطلوبة'); }
  else parts.ERP = [W_ERP, W_ERP];

  if (job.location) {
    var loc = norm(c['Current Location']), want = norm(job.location);
    if (!loc) { parts.Location = [0, W_LOC]; why.push('موقع المرشح غير محدد'); }
    else if (loc.indexOf(want) >= 0 || want.indexOf(loc) >= 0) parts.Location = [W_LOC, W_LOC];
    else { parts.Location = [0, W_LOC]; why.push('الموقع/المدينة مختلف'); }
  } else parts.Location = [W_LOC, W_LOC];

  var score = 0; Object.keys(parts).forEach(function (k) { score += parts[k][0]; });
  return { score: score, parts: parts, why: why };
}
function rating(s) { return s >= 80 ? 'Strong' : s >= 65 ? 'Good' : s >= 50 ? 'Possible' : 'Weak'; }

function uniqueSheetName(name, used) {
  var base = String(name).replace(/[\[\]:*?\/\\]/g, ' ').replace(/\s+/g, ' ').trim().slice(0, 31) || 'Sheet', cand = base, n = 2;
  while (used[cand.toLowerCase()]) { var suf = ' (' + n++ + ')'; cand = base.slice(0, 31 - suf.length) + suf; }
  used[cand.toLowerCase()] = 1;
  return cand;
}
function deleteSheetsByPrefix(prefix) {
  var ss = SpreadsheetApp.getActive();
  ss.getSheets().forEach(function (s) { if (s.getName().indexOf(prefix) === 0) ss.deleteSheet(s); });
}
function styleOutput(ws, hdr, nrows, widths) {
  var h = ws.getRange(1, 1, 1, hdr.length);
  h.setBackground(HDR_BG).setFontColor('#FFFFFF').setFontWeight('bold').setHorizontalAlignment('center').setVerticalAlignment('middle').setWrap(true);
  if (nrows > 0) ws.getRange(2, 1, nrows, hdr.length).setVerticalAlignment('top').setWrap(true);
  widths.forEach(function (w, i) { ws.setColumnWidth(i + 1, w * 7); });
  ws.setRowHeight(1, 34);
  ws.setFrozenRows(1); ws.setFrozenColumns(3);
  if (nrows > 0) ws.getRange(1, 1, nrows + 1, hdr.length).createFilter();
}
function alertSafe(msg) { try { SpreadsheetApp.getUi().alert(msg); } catch (e) { log(msg); } }

// ------------------------------------------------------------------ MATCH
var MATCH_COLS = ['Rank', 'Candidate ID', 'Name', 'Total Score (100)', 'Rating', 'Title (15)', 'Field Exp (30)', 'Industry (20)', 'Education (10)', 'Keywords (10)', 'ERP (10)', 'Location (5)', 'Last Position', 'Target Position', 'Experience (Years)', 'Education', 'Nationality', 'Current Location', 'Expected Salary (AED)', 'Language 1', 'Language 2', 'Language 3', 'Email', 'Mobile', 'Notes / Why'];
var MATCH_W = [7, 13, 26, 11, 11, 9, 11, 11, 11, 11, 9, 10, 28, 28, 11, 32, 14, 18, 12, 11, 11, 11, 28, 18, 60];
var PART_KEYS = ['Title', 'Field Exp', 'Industry', 'Education', 'Keywords', 'ERP', 'Location'];

function runMatch(silent) {
  var jobs = readJobs();
  if (!jobs.length) return alertSafe('لا توجد وظائف في ورقة Jobs.');
  var cands = readTable(SH.CAND).rows, texts = readTextMap();
  if (!cands.length) return alertSafe('ورقة Candidates فارغة.');
  deleteSheetsByPrefix('M - ');
  var ss = SpreadsheetApp.getActive(), used = {}, topRows = [], summary = [['Job Title', 'Candidates', 'Strong (80+)', 'Good (65-79)', 'Possible (50-64)', 'Weak (<50)', 'Best Score', 'Sheet', 'Best 7']];
  jobs.forEach(function (job) {
    var rows = cands.map(function (c) {
      var ct = candidateText(c, texts), res = scoreCandidate(job, c, ct.text), why = res.why.slice();
      if (!ct.full) why.push('لا يوجد نص كامل للسيرة - المطابقة على الحقول المتاحة فقط');
      var notes = [c['Notes'], why.join('; ')].filter(String).join('; ');
      return [0, c['Candidate ID'], c['Name'], res.score, rating(res.score)]
        .concat(PART_KEYS.map(function (k) { return res.parts[k][0]; }))
        .concat([c['Last Position'], c['Target Position'], c['Experience (Years)'], c['Education'], c['Nationality'], c['Current Location'], c['Expected Salary (AED)'], c['Language 1'], c['Language 2'], c['Language 3'], c['Email'], c['Mobile'], notes, toNum(c['Experience (Years)']) || 0]);
    });
    rows.sort(function (a, b) { return (b[3] - a[3]) || (b[b.length - 1] - a[a.length - 1]) || String(a[1]).localeCompare(String(b[1])); });
    rows.forEach(function (r, i) { r[0] = i + 1; r.pop(); });
    var name = uniqueSheetName('M - ' + job.title, used), ws = ss.insertSheet(name);
    ws.getRange(1, 1, 1, MATCH_COLS.length).setValues([MATCH_COLS]);
    if (rows.length) {
      ws.getRange(2, 1, rows.length, MATCH_COLS.length).setNumberFormat('@').setValues(rows.map(function (r) { return r.map(function (v) { return v === null ? '' : v; }); }));
      ws.getRange(2, 4, rows.length, 1).setNumberFormat('0');
      ws.getRange(2, 4, rows.length, 2).setBackgrounds(rows.map(function (r) { var f = RATING_FILL[r[4]]; return [f, f]; }));
      ws.getRange(2, 4, rows.length, 1).setFontWeight('bold');
      ws.getRange(2, 1, Math.min(TOP_N, rows.length), 1).setBackground('#FFE699').setFontWeight('bold');
    }
    styleOutput(ws, MATCH_COLS, rows.length, MATCH_W);
    var cnt = { Strong: 0, Good: 0, Possible: 0, Weak: 0 }; rows.forEach(function (r) { cnt[r[4]]++; });
    var best = rows.slice(0, TOP_N);
    best.forEach(function (r) { topRows.push([job.title, r[0], r[1], r[2], r[3], r[4], r[12], r[15], r[16], r[17], r[18], [r[19], r[20], r[21]].filter(String).join(', '), r[22], r[23], r[24]]); });
    summary.push([job.title, rows.length, cnt.Strong, cnt.Good, cnt.Possible, cnt.Weak, rows.length ? rows[0][3] : 0, name, best.map(function (r) { return r[2] + ' (' + r[3] + ')'; }).join(' | ')]);
  });
  var sum = ss.getSheetByName(SH.SUM) || ss.insertSheet(SH.SUM);
  sum.clear(); sum.getRange(1, 1, summary.length, summary[0].length).setValues(summary);
  sum.getRange(1, 1, 1, summary[0].length).setBackground(HDR_BG).setFontColor('#FFFFFF').setFontWeight('bold').setHorizontalAlignment('center');
  [30, 12, 14, 14, 16, 12, 12, 30, 90].forEach(function (w, i) { sum.setColumnWidth(i + 1, w * 7); });
  sum.setFrozenRows(1);
  // ورقة Top_7: أفضل 7 مرشحين لكل وظيفة
  var TOP_COLS = ['Job Title', 'Rank', 'Candidate ID', 'Name', 'Score', 'Rating', 'Last Position', 'Education', 'Nationality', 'Current Location', 'Expected Salary (AED)', 'Languages', 'Email', 'Mobile', 'Notes / Why'];
  var top = ss.getSheetByName('Top_7') || ss.insertSheet('Top_7');
  if (top.getFilter()) top.getFilter().remove();
  top.clear();
  top.getRange(1, 1, 1, TOP_COLS.length).setValues([TOP_COLS]);
  if (topRows.length) {
    top.getRange(2, 1, topRows.length, TOP_COLS.length).setNumberFormat('@').setValues(topRows);
    top.getRange(2, 5, topRows.length, 2).setBackgrounds(topRows.map(function (r) { var f = RATING_FILL[r[5]]; return [f, f]; }));
  }
  styleOutput(top, TOP_COLS, topRows.length, [28, 7, 13, 26, 8, 10, 28, 30, 14, 18, 12, 24, 28, 18, 60]);
  ss.setActiveSheet(top);
  var msg = 'تمت المطابقة: ' + jobs.length + ' وظيفة × ' + cands.length + ' مرشح. أفضل ' + TOP_N + ' لكل وظيفة في ورقة Top_7، والتفاصيل في Matching_Summary وأوراق "M - ...".';
  log(msg);
  if (!silent) alertSafe(msg);
}

// ------------------------------------------------------------------ SHORTLIST (بلا جواز/هوية/ميلاد/جنس)
var SL_COLS = ['Rank', 'Candidate ID', 'Name', 'Score', 'Rating', 'Nationality', 'Education', 'Last Position', 'Target Position', 'Experience (Years)', 'Current Location', 'Current Salary (AED)', 'Expected Salary (AED)', 'Language 1', 'Language 2', 'Language 3', 'Email', 'Mobile', 'WhatsApp', 'Notice Period', 'Notes'];
var SL_W = [7, 13, 26, 8, 10, 14, 30, 26, 26, 11, 18, 12, 12, 11, 11, 11, 28, 18, 18, 14, 34];

function runShortlist() {
  var rules = readTable(SH.FILT).rows.filter(function (r) { return String(r[F_COLS[0]] || '').trim(); });
  if (!rules.length) return alertSafe('لا توجد شروط في ورقة Filters (صف لكل قائمة).');
  var cands = readTable(SH.CAND).rows, texts = readTextMap(), jobs = {};
  readJobs().forEach(function (j) { jobs[j.title.toLowerCase()] = j; });
  deleteSheetsByPrefix('SL - ');
  var ss = SpreadsheetApp.getActive(), used = {}, report = [];
  rules.forEach(function (rule) {
    var name = String(rule[F_COLS[0]]).trim(), jt = String(rule[F_COLS[1]] || '').trim(), job = jt ? jobs[jt.toLowerCase()] : null;
    var top = toNum(rule[F_COLS[2]]), minScore = toNum(rule[F_COLS[3]]), minExp = toNum(rule[F_COLS[4]]), maxExp = toNum(rule[F_COLS[5]]);
    var eduTxt = String(rule[F_COLS[6]] || '').trim(), minEdu = eduTxt ? eduLevel(eduTxt) : 0;
    var nats = parseList(rule[F_COLS[7]]).map(norm), loc = norm(rule[F_COLS[8]]);
    var maxSal = toNum(rule[F_COLS[9]]), langs = parseList(rule[F_COLS[10]]).map(norm), sector = norm(rule[F_COLS[11]]);
    var rows = [];
    cands.forEach(function (c) {
      var y = toNum(c['Experience (Years)']);
      if (minExp != null && (y == null || y < minExp)) return;
      if (maxExp != null && (y == null || y > maxExp)) return;
      if (minEdu && eduLevel(c['Education']) < minEdu) return;
      var cn = norm(c['Nationality']);
      if (nats.length && !nats.some(function (n) { return n && (n === cn || cn.indexOf(n) >= 0); })) return;
      if (loc && norm(c['Current Location']).indexOf(loc) < 0) return;
      var sal = toNum(c['Expected Salary (AED)']);
      if (maxSal != null && sal != null && sal > maxSal) return;
      if (langs.length) {
        var cl = [c['Language 1'], c['Language 2'], c['Language 3']].map(norm);
        if (!langs.every(function (l) { return cl.some(function (x) { return x && x.indexOf(l) >= 0; }); })) return;
      }
      if (sector && norm(c['Sector']).indexOf(sector) < 0) return;
      var sc = '', rt = '', note = c['Notes'];
      if (job) {
        var ct = candidateText(c, texts), res = scoreCandidate(job, c, ct.text);
        if (minScore != null && res.score < minScore) return;
        sc = res.score; rt = rating(res.score);
        note = [c['Notes'], res.why.join('; ')].filter(String).join('; ');
      }
      rows.push([0, c['Candidate ID'], c['Name'], sc, rt, c['Nationality'], c['Education'], c['Last Position'], c['Target Position'], c['Experience (Years)'], c['Current Location'], c['Current Salary (AED)'], c['Expected Salary (AED)'], c['Language 1'], c['Language 2'], c['Language 3'], c['Email'], c['Mobile'], c['WhatsApp'], c['Notice Period'], note, y || 0]);
    });
    rows.sort(function (a, b) { return ((b[3] === '' ? 0 : b[3]) - (a[3] === '' ? 0 : a[3])) || (b[b.length - 1] - a[a.length - 1]); });
    if (top) rows = rows.slice(0, Math.floor(top));
    rows.forEach(function (r, i) { r[0] = i + 1; r.pop(); });
    var ws = ss.insertSheet(uniqueSheetName('SL - ' + name, used));
    ws.getRange(1, 1, 1, SL_COLS.length).setValues([SL_COLS]);
    if (rows.length) ws.getRange(2, 1, rows.length, SL_COLS.length).setNumberFormat('@').setValues(rows);
    styleOutput(ws, SL_COLS, rows.length, SL_W);
    report.push(name + ': ' + rows.length);
  });
  alertSafe('تم إنشاء القوائم المختصرة:\n' + report.join('\n'));
}
