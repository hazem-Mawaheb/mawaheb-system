/** مكتبة المسميات الوظيفية: كل سطر "English|العربية". تُقدَّم للموقع عبر doGet?action=titles وتُكتب في ورقة Titles. */
var SECTORS = [
  ['oilgas', 'النفط والغاز', 'Oil & Gas'],
  ['transport', 'النقليات واللوجستيات', 'Transport & Logistics'],
  ['tourism', 'السياحة والسفر', 'Tourism & Travel'],
  ['restaurants', 'المطاعم والمطابخ', 'Restaurants & Kitchens'],
  ['hotels', 'الفنادق والضيافة', 'Hotels & Hospitality'],
  ['construction', 'المقاولات (بناء وطرق)', 'Construction & Roads'],
  ['hospitals', 'المستشفيات', 'Hospitals'],
  ['clinics', 'العيادات', 'Clinics'],
  ['retail', 'التجزئة والتجارة', 'Retail & Trade'],
  ['admin', 'وظائف إدارية ومكتبية عامة', 'General Admin & Corporate']
];

var TITLES_RAW = {
oilgas: `Petroleum Engineer|مهندس بترول
Reservoir Engineer|مهندس مكامن
Drilling Engineer|مهندس حفر
Production Engineer|مهندس إنتاج
Process Engineer|مهندس عمليات
Piping Engineer|مهندس أنابيب
Pipeline Engineer|مهندس خطوط أنابيب
Mechanical Engineer|مهندس ميكانيكا
Electrical Engineer|مهندس كهرباء
Instrumentation Engineer|مهندس أجهزة قياس وتحكم
Corrosion Engineer|مهندس تآكل
Mud Engineer|مهندس سوائل حفر
Geologist|جيولوجي
Geophysicist|جيوفيزيائي
HSE Manager|مدير السلامة والصحة والبيئة
HSE Officer|مسؤول سلامة وصحة وبيئة
Safety Supervisor|مشرف سلامة
Fire Fighter|رجل إطفاء
Rig Manager|مدير منصة حفر
Toolpusher|مشرف حفر (تول بوشر)
Wellsite Supervisor|مشرف موقع بئر
Driller|حفّار
Assistant Driller|مساعد حفّار
Derrickman|عامل برج حفر
Roughneck|عامل حفر (رفنك)
Roustabout|عامل حقول نفط
Crane Operator|مشغل رافعة
Production Operator|مشغل إنتاج
Control Room Operator|مشغل غرفة تحكم
Plant Operator|مشغل محطة
Wireline Operator|مشغل ويرلاين
Maintenance Planner|مخطط صيانة
Maintenance Supervisor|مشرف صيانة
Mechanical Technician|فني ميكانيكا
Electrical Technician|فني كهرباء
Instrument Technician|فني أجهزة دقيقة
Rotating Equipment Technician|فني معدات دوارة
Welder|لحّام
Pipe Fitter|فيتر أنابيب
Rigger|ريجر (تعليق أحمال)
Scaffolder|مركّب سقالات
Painter / Blaster|دهّان / رمّال
NDT Technician|فني فحص غير إتلافي
QA/QC Inspector|مفتش جودة
Welding Inspector|مفتش لحام
Coating Inspector|مفتش طلاء
Lab Technician|فني مختبر
Chemist|كيميائي
Offshore Medic|مسعف بحري
Camp Boss|مدير مخيم
Storekeeper|أمين مستودع
Heavy Equipment Operator|مشغل معدات ثقيلة
Heavy Truck Driver|سائق شاحنة ثقيلة`,
transport: `Logistics Manager|مدير لوجستيات
Transport Manager|مدير نقل
Fleet Manager|مدير أسطول
Operations Manager|مدير عمليات
Warehouse Manager|مدير مستودع
Supply Chain Manager|مدير سلسلة الإمداد
Logistics Coordinator|منسق لوجستيات
Transport Coordinator|منسق نقل
Dispatcher|مرسِل (ديسباتشر)
Traffic Controller|مراقب حركة
Freight Forwarder|وكيل شحن
Customs Clearance Officer|مخلّص جمركي
Customs Clerk|موظف جمارك
Import Export Officer|مسؤول استيراد وتصدير
Documentation Officer|مسؤول مستندات
Shipping Coordinator|منسق شحن
Port Operations Officer|مسؤول عمليات ميناء
Warehouse Supervisor|مشرف مستودع
Warehouse Keeper|أمين مستودع
Forklift Operator|مشغل رافعة شوكية
Reach Truck Operator|مشغل ريتش تراك
Picker / Packer|عامل تجهيز وتعبئة
Loader|عامل تحميل
Heavy Truck Driver|سائق شاحنة ثقيلة
Trailer Driver|سائق تريلا
Tanker Driver|سائق صهريج
Light Truck Driver|سائق شاحنة خفيفة
Pickup Driver|سائق بيك أب
Bus Driver|سائق حافلة
School Bus Driver|سائق حافلة مدرسية
Taxi Driver|سائق تاكسي
Limousine Driver|سائق ليموزين
Delivery Driver|سائق توصيل
Delivery Rider|مندوب توصيل (دراجة)
Chauffeur|سائق خاص
Bus Attendant|مرافق حافلة
Transport Supervisor|مشرف نقل
Vehicle Inspector|مفتش مركبات
Auto Mechanic|ميكانيكي سيارات
Heavy Vehicle Mechanic|ميكانيكي مركبات ثقيلة
Auto Electrician|كهربائي سيارات
Body Shop Technician|فني سمكرة ودهان
Tyre Technician|فني إطارات
Vehicle Washer|عامل غسيل مركبات
Crane Operator|مشغل رافعة
Marine Captain|ربان
Deck Hand|بحّار
Marine Engineer|مهندس بحري
Railway Operator|مشغل سكك حديدية
Cargo Handler|عامل مناولة شحن
Ground Handler|عامل خدمات أرضية
Aircraft Technician|فني طائرات`,
tourism: `Tourism Manager|مدير سياحة
Travel Agency Manager|مدير وكالة سفر
Tour Operator|منظم رحلات
Tour Guide|مرشد سياحي
Tour Coordinator|منسق رحلات
Travel Consultant|مستشار سفر
Ticketing Agent|موظف حجز تذاكر
Reservation Agent|موظف حجوزات
Visa Officer|مسؤول تأشيرات
Sales Executive (Travel)|مسؤول مبيعات سياحة
Destination Specialist|أخصائي وجهات
Desert Safari Guide|مرشد سفاري
Safari Driver|سائق سفاري
Dhow Cruise Staff|طاقم رحلات بحرية
Yacht Captain|قبطان يخت
Yacht Crew|طاقم يخت
Boat Captain|ربان قارب
Diving Instructor|مدرب غوص
Water Sports Instructor|مدرب رياضات مائية
Theme Park Operator|مشغل ألعاب ترفيه
Ride Attendant|مشرف ألعاب
Event Coordinator|منسق فعاليات
Event Manager|مدير فعاليات
Museum Guide|مرشد متحف
Customer Service Agent|موظف خدمة عملاء
Call Center Agent|موظف مركز اتصال
Airline Cabin Crew|مضيف طيران
Ground Staff|موظف خدمات أرضية
Airport Check-in Agent|موظف تسجيل مسافرين
Hajj & Umrah Coordinator|منسق حج وعمرة
Tourism Marketing Executive|مسؤول تسويق سياحي
Brochure Distributor|موزّع نشرات
Tour Bus Driver|سائق حافلة سياحية
Photographer|مصوّر
Souvenir Shop Attendant|بائع هدايا تذكارية`,
restaurants: `Restaurant Manager|مدير مطعم
Assistant Restaurant Manager|مساعد مدير مطعم
Executive Chef|شيف تنفيذي
Head Chef|رئيس طهاة
Sous Chef|مساعد شيف
Chef de Partie|شيف قسم
Commis Chef|مساعد طاهٍ
Cook|طبّاخ
Arabic Cuisine Chef|شيف مأكولات عربية
Indian Cuisine Chef|شيف مأكولات هندية
Chinese Cuisine Chef|شيف مأكولات صينية
Italian Cuisine Chef|شيف مأكولات إيطالية
Grill Cook|طاهي مشاوي
Tandoor Cook|طاهي تندور
Shawarma Cook|طاهي شاورما
Pizza Maker|صانع بيتزا
Pastry Chef|شيف حلويات
Baker|خبّاز
Arabic Sweets Maker|صانع حلويات عربية
Sandwich Maker|محضّر ساندويشات
Juice Maker|محضّر عصائر
Barista|باريستا
Coffee Maker|محضّر قهوة
Cafeteria Worker|عامل كافتيريا
Waiter|نادل
Waitress|نادلة
Captain Waiter|كابتن خدمة
Host / Hostess|مضيف / مضيفة استقبال
Cashier|كاشير
Food Runner|ناقل أطباق
Bartender|ساقي مشروبات
Kitchen Steward|عامل نظافة مطبخ
Dishwasher|غسّال أطباق
Kitchen Helper|مساعد مطبخ
Butcher|جزّار
Food Safety Officer|مسؤول سلامة غذاء
Food Controller|مراقب أغذية
Store Keeper (F&B)|أمين مخزن مأكولات
Catering Supervisor|مشرف تموين
Catering Driver|سائق تموين
Delivery Rider|مندوب توصيل
Cloud Kitchen Manager|مدير مطبخ سحابي
Canteen Supervisor|مشرف كانتين`,
hotels: `Hotel General Manager|مدير عام فندق
Resident Manager|مدير مقيم
Front Office Manager|مدير مكتب استقبال
Assistant Front Office Manager|مساعد مدير استقبال
Front Desk Agent|موظف استقبال
Receptionist|موظف استقبال فندقي
Night Auditor|مدقق ليلي
Guest Relations Officer|مسؤول علاقات نزلاء
Concierge|كونسيرج
Bell Boy|حمّال أمتعة
Doorman|حارس بوابة فندق
Reservation Manager|مدير حجوزات
Reservation Agent|موظف حجوزات
Housekeeping Manager|مدير خدمة الغرف
Executive Housekeeper|رئيس قسم التدبير الفندقي
Housekeeping Supervisor|مشرف تدبير فندقي
Room Attendant|عامل غرف
Chambermaid|عاملة غرف
Laundry Attendant|عامل مغسلة
Public Area Cleaner|عامل نظافة مرافق
Food & Beverage Manager|مدير أغذية ومشروبات
Banquet Manager|مدير ولائم
Banquet Waiter|نادل ولائم
Room Service Waiter|نادل خدمة الغرف
Restaurant Supervisor|مشرف مطعم
Hotel Chef|شيف فندق
Hotel Pastry Chef|شيف حلويات فندق
Bartender|ساقي
Spa Manager|مدير سبا
Spa Therapist|أخصائي سبا
Massage Therapist|أخصائي تدليك
Fitness Trainer|مدرب لياقة
Lifeguard|منقذ سباحة
Pool Attendant|عامل مسبح
Hotel Sales Manager|مدير مبيعات فندق
Revenue Manager|مدير إيرادات
Hotel Accountant|محاسب فندق
Hotel Purchasing Officer|مسؤول مشتريات فندق
Chief Engineer (Hotel)|رئيس مهندسي فندق
Maintenance Technician (Hotel)|فني صيانة فندق
Hotel Security Officer|حارس أمن فندق
Hotel Driver|سائق فندق
Valet Parking Attendant|عامل صف سيارات
Event Coordinator|منسق فعاليات
Housekeeping Storekeeper|أمين مخزن تدبير
Hotel HR Officer|مسؤول موارد بشرية فندق
Training Officer|مسؤول تدريب`,
construction: `Project Manager|مدير مشروع
Construction Manager|مدير إنشاءات
Site Manager|مدير موقع
Contracts Manager|مدير عقود
Project Engineer|مهندس مشروع
Site Engineer|مهندس موقع
Civil Engineer|مهندس مدني
Structural Engineer|مهندس إنشائي
Architect|مهندس معماري
MEP Engineer|مهندس ميكانيكا وكهرباء وسباكة
Mechanical Engineer|مهندس ميكانيكا
Electrical Engineer|مهندس كهرباء
Highway Engineer|مهندس طرق
Road Works Engineer|مهندس أعمال طرق
Surveyor|مساح
Land Surveyor|مساح أراضي
Assistant Surveyor|مساعد مساح
Quantity Surveyor|مهندس كميات
Cost Engineer|مهندس تكاليف
Planning Engineer|مهندس تخطيط
Estimation Engineer|مهندس مناقصات
Document Controller|مراقب مستندات
Safety Engineer|مهندس سلامة
Safety Officer|مسؤول سلامة
QA/QC Engineer|مهندس جودة
Material Engineer|مهندس مواد
Lab Technician (Soil/Concrete)|فني مختبر تربة وخرسانة
Foreman|مراقب عمال (فورمان)
General Foreman|فورمان عام
Supervisor|مشرف
Mason|بنّاء
Block Mason|عامل بناء طوب
Plasterer|مبلّط ومحّار
Tile Fixer|مركّب بلاط
Marble Fixer|مركّب رخام
Carpenter|نجّار
Shuttering Carpenter|نجّار مسلّح (شتر)
Steel Fixer|حدّاد مسلّح
Concrete Finisher|عامل خرسانة
Painter|دهّان
Gypsum Fixer|مركّب جبس
Aluminium Fabricator|فني ألمنيوم
Glass Fitter|مركّب زجاج
Welder|لحّام
Steel Fabricator|فني تصنيع حديد
Rigger|ريجر
Scaffolder|مركّب سقالات
Electrician|كهربائي
Plumber|سبّاك
HVAC Technician|فني تكييف وتبريد
Ductman|فني دكت
Pipe Fitter|فيتر أنابيب
Fire Fighting Technician|فني مكافحة حريق
Waterproofing Technician|فني عزل
Asphalt Paver Operator|مشغل فرادة أسفلت
Excavator Operator|مشغل حفّارة
Bulldozer Operator|مشغل بلدوزر
Grader Operator|مشغل قريدر
Roller Operator|مشغل حدّالة
Loader Operator|مشغل لودر
Backhoe Operator|مشغل باكهو
Crane Operator|مشغل رافعة
Tower Crane Operator|مشغل رافعة برجية
Concrete Pump Operator|مشغل مضخة خرسانة
Dump Truck Driver|سائق قلاب
Mixer Truck Driver|سائق خلاطة
Road Marking Worker|عامل دهان طرق
Pipe Layer|عامل مدّ أنابيب
Storekeeper|أمين مستودع
Timekeeper|مراقب دوام
Site Cleaner|عامل نظافة موقع
General Labourer|عامل عادي
Helper|مساعد عامل`,
hospitals: `Medical Director|مدير طبي
Hospital Administrator|مدير مستشفى
Consultant Physician|استشاري طب باطني
General Practitioner|طبيب عام
Specialist Physician|أخصائي طب
Surgeon|جرّاح
Anesthesiologist|طبيب تخدير
Emergency Physician|طبيب طوارئ
Pediatrician|طبيب أطفال
Obstetrician / Gynecologist|طبيب نساء وولادة
Cardiologist|طبيب قلب
Radiologist|أخصائي أشعة
Pathologist|أخصائي أمراض
ICU Physician|طبيب عناية مركزة
Nursing Director|مدير تمريض
Head Nurse|رئيسة تمريض
Charge Nurse|ممرض مسؤول
Registered Nurse|ممرض مسجّل
Staff Nurse|ممرض
ICU Nurse|ممرض عناية مركزة
ER Nurse|ممرض طوارئ
OR Nurse|ممرض عمليات
Nursing Assistant|مساعد ممرض
Midwife|قابلة
Paramedic|مسعف
EMT|فني طوارئ طبية
Ambulance Driver|سائق إسعاف
Pharmacist|صيدلاني
Pharmacy Technician|فني صيدلة
Medical Lab Technologist|أخصائي مختبر
Lab Technician|فني مختبر
Phlebotomist|فني سحب دم
Radiographer|فني أشعة
CT / MRI Technologist|فني أشعة مقطعية ورنين
Physiotherapist|أخصائي علاج طبيعي
Respiratory Therapist|أخصائي علاج تنفسي
Dietitian|أخصائي تغذية
Anesthesia Technician|فني تخدير
Operating Room Technician|فني غرف عمليات
Sterilization Technician|فني تعقيم
Biomedical Engineer|مهندس أجهزة طبية
Biomedical Technician|فني أجهزة طبية
Medical Coder|مبرمج ترميز طبي
Medical Records Officer|مسؤول سجلات طبية
Medical Secretary|سكرتير طبي
Patient Services Officer|مسؤول خدمات مرضى
Insurance Coordinator|منسق تأمين
Receptionist|موظف استقبال
Infection Control Officer|مسؤول مكافحة عدوى
Quality Officer (Healthcare)|مسؤول جودة صحية
Ward Boy|مساعد جناح
Patient Transporter|ناقل مرضى
Housekeeper (Hospital)|عامل نظافة مستشفى
Hospital Security Guard|حارس أمن مستشفى
Hospital Storekeeper|أمين مخزن مستشفى
Mortuary Attendant|فني مشرحة`,
clinics: `Clinic Manager|مدير عيادة
Dentist|طبيب أسنان
Dental Specialist|أخصائي أسنان
Orthodontist|أخصائي تقويم أسنان
Dental Assistant|مساعد طبيب أسنان
Dental Hygienist|أخصائي صحة فم وأسنان
Dental Technician|فني أسنان
Dermatologist|طبيب جلدية
Cosmetologist|أخصائي تجميل
Laser Technician|فني ليزر
Aesthetic Nurse|ممرض تجميل
Ophthalmologist|طبيب عيون
Optometrist|أخصائي بصريات
Optician|فني نظارات
ENT Specialist|طبيب أنف وأذن وحنجرة
Pediatrician|طبيب أطفال
Gynecologist|طبيب نساء
Family Medicine Physician|طبيب أسرة
General Practitioner|طبيب عام
Physiotherapist|أخصائي علاج طبيعي
Psychologist|أخصائي نفسي
Speech Therapist|أخصائي نطق
Occupational Therapist|أخصائي علاج وظيفي
Nutritionist|أخصائي تغذية
Clinic Nurse|ممرض عيادة
Nursing Assistant|مساعد ممرض
Pharmacist|صيدلاني
Lab Technician|فني مختبر
X-Ray Technician|فني أشعة
Medical Receptionist|موظف استقبال عيادة
Appointment Coordinator|منسق مواعيد
Insurance Claims Officer|مسؤول مطالبات تأمين
Medical Biller|محاسب فواتير طبية
Patient Relations Officer|مسؤول علاقات مرضى
Medical Sales Representative|مندوب مبيعات طبي
Clinic Cleaner|عامل نظافة عيادة
Clinic Driver / PRO|سائق ومندوب عيادة`,
retail: `Retail Manager|مدير تجزئة
Store Manager|مدير متجر
Assistant Store Manager|مساعد مدير متجر
Branch Manager|مدير فرع
Area Manager|مدير منطقة
Supermarket Manager|مدير سوبرماركت
Category Manager|مدير فئة منتجات
Buyer|مشتري
Merchandiser|منسق عرض بضائع
Visual Merchandiser|منسق عرض بصري
Supervisor|مشرف
Sales Executive|مسؤول مبيعات
Sales Representative|مندوب مبيعات
Sales Associate|بائع
Salesman|بائع
Saleswoman|بائعة
Cashier|كاشير
Head Cashier|رئيس كاشير
Customer Service Agent|موظف خدمة عملاء
Showroom Sales Consultant|مستشار مبيعات معرض
Car Sales Executive|مسؤول مبيعات سيارات
Mobile Phone Salesman|بائع هواتف
Electronics Salesman|بائع إلكترونيات
Jewellery Salesman|بائع مجوهرات
Perfume Salesman|بائع عطور
Fashion Consultant|مستشار أزياء
Tailor|خيّاط
Optical Salesman|بائع نظارات
Pharmacy Assistant|مساعد صيدلية
Stock Controller|مراقب مخزون
Inventory Clerk|موظف جرد
Storekeeper|أمين مستودع
Shelf Stacker|عامل رصّ رفوف
Butcher|جزّار
Fishmonger|بائع أسماك
Baker|خبّاز
Fruit & Vegetable Attendant|عامل خضار وفواكه
Deli Attendant|عامل ديلي
Packer|عامل تعبئة
Delivery Driver|سائق توصيل
Delivery Rider|مندوب توصيل
Loader|عامل تحميل
E-commerce Executive|مسؤول تجارة إلكترونية
Online Order Picker|محضّر طلبات إلكترونية
Loss Prevention Officer|مسؤول منع خسائر
Security Guard|حارس أمن
Trading Manager|مدير تجارة
Wholesale Salesman|بائع جملة`,
admin: `General Manager|مدير عام
Operations Manager|مدير عمليات
Human Capital Director|مدير رأس المال البشري
HR Manager|مدير موارد بشرية
HR Business Partner|شريك أعمال موارد بشرية
HR Generalist|أخصائي موارد بشرية عام
HR Officer|مسؤول موارد بشرية
HR Assistant|مساعد موارد بشرية
Recruitment Specialist|أخصائي توظيف
Recruiter|مسؤول استقطاب
Payroll Specialist|أخصائي رواتب
Training Manager|مدير تدريب
Government Relations Officer (PRO)|مندوب علاقات حكومية (PRO)
PRO Manager|مدير علاقات حكومية
Administration Manager|مدير إدارة
Office Manager|مدير مكتب
Admin Officer|مسؤول إداري
Administrative Assistant|مساعد إداري
Executive Assistant|مساعد تنفيذي
Personal Assistant|مساعد شخصي
Secretary|سكرتير
Receptionist|موظف استقبال
Data Entry Clerk|مدخل بيانات
Document Controller|مراقب مستندات
Filing Clerk|موظف أرشيف
Finance Manager|مدير مالي
Financial Controller|مراقب مالي
Chief Accountant|رئيس حسابات
Senior Accountant|محاسب أول
Accountant|محاسب
Assistant Accountant|مساعد محاسب
Accounts Payable Officer|مسؤول حسابات دائنة
Accounts Receivable Officer|مسؤول حسابات مدينة
Credit Controller|مراقب ائتمان
Auditor|مدقق حسابات
Internal Auditor|مدقق داخلي
Cost Accountant|محاسب تكاليف
Treasury Officer|مسؤول خزينة
Procurement Manager|مدير مشتريات
Procurement Officer|مسؤول مشتريات
Purchasing Assistant|مساعد مشتريات
Store Manager|مدير مخازن
Sales Manager|مدير مبيعات
Business Development Manager|مدير تطوير أعمال
Marketing Manager|مدير تسويق
Marketing Executive|مسؤول تسويق
Digital Marketing Specialist|أخصائي تسويق رقمي
Graphic Designer|مصمم جرافيك
Social Media Specialist|أخصائي وسائل تواصل
Content Writer|كاتب محتوى
Public Relations Officer|مسؤول علاقات عامة
Customer Service Manager|مدير خدمة عملاء
Customer Service Representative|ممثل خدمة عملاء
Call Center Agent|موظف مركز اتصال
Legal Advisor|مستشار قانوني
Legal Officer|مسؤول قانوني
Contracts Administrator|مسؤول عقود
Compliance Officer|مسؤول امتثال
IT Manager|مدير تقنية المعلومات
IT Support Specialist|أخصائي دعم فني
Network Engineer|مهندس شبكات
System Administrator|مدير نظم
Software Developer|مطوّر برمجيات
Web Developer|مطوّر مواقع
Database Administrator|مدير قواعد بيانات
ERP Specialist|أخصائي أنظمة ERP
Data Analyst|محلل بيانات
Facilities Manager|مدير مرافق
Security Manager|مدير أمن
Security Guard|حارس أمن
Office Boy|عامل خدمات مكتبية
Driver|سائق
Messenger|مندوب مكتب
Translator|مترجم
Teacher|معلم
Safety & Quality Manager|مدير السلامة والجودة`
};

/** {sectorId: [[en, ar], ...]} بلا تكرار داخل القطاع */
function getTitlesLib() {
  var out = {};
  Object.keys(TITLES_RAW).forEach(function (k) {
    var seen = {}, arr = [];
    TITLES_RAW[k].split('\n').forEach(function (l) {
      var p = l.split('|');
      if (p.length < 2) return;
      var en = p[0].trim(), ar = p[1].trim();
      if (!en || seen[en.toLowerCase()]) return;
      seen[en.toLowerCase()] = 1;
      arr.push([en, ar]);
    });
    out[k] = arr;
  });
  return out;
}
