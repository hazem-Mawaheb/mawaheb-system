/** استخراج بيانات السيرة الذاتية من النص (نفس منطق main.py، مع الراتب واللغات). لا يخمّن: الحقل غير الموجود يبقى فارغاً. */

function cvClean(t) {
  t = String(t || '').replace(/\u00a0/g, ' ');
  t = t.replace(/[٠-٩]/g, function (d) { return '٠١٢٣٤٥٦٧٨٩'.indexOf(d); });
  t = t.replace(/[۰-۹]/g, function (d) { return '۰۱۲۳۴۵۶۷۸۹'.indexOf(d); });
  return t.replace(/[ \t]+/g, ' ').replace(/\n{3,}/g, '\n\n').trim();
}
function rxEsc(s) { return String(s).replace(/[.*+?^${}()|[\]\\]/g, '\\$&'); }
function trimV(s) { return String(s || '').replace(/^[ :\-|،]+|[ :\-|،]+$/g, ''); }

var CUT2 = /\s+(?:Date of Birth|(?:[A-Za-z\/]+ )?(?:Expiry|Expires|Number|No\.?|Date|Birth|Status|Type|Nationality|Gender|Sex|Email|Mobile|Phone|Tel|WhatsApp|Location|Address|Education|Position|Name|Visa|ID|Notice|Availability|Experience|Residency|DOB))\s*:\s/i;

function labeled(text, labels, nl, loose) {
  var alt = labels.slice().sort(function (a, b) { return b.length - a.length; }).map(rxEsc).join('|');
  var start = '(?<![A-Za-z])(?:' + alt + ')';
  var ok = function (m) { return m && trimV(m[1]); };
  var m = new RegExp(start + '[ \\t]*[:：\\-–|][ \\t]*([^\\n|]+)', 'i').exec(text);
  if (!ok(m) && nl) m = new RegExp(start + '[ \\t]*[:：]?[ \\t]*\\n[ \\t]*([^\\n|]+)', 'i').exec(text);
  if (!ok(m) && loose) m = new RegExp(start + '[ \\t]+([^\\n|]+)', 'i').exec(text);
  if (!m) return '';
  var v = trimV(m[1]).split(/\s{2,}/)[0];
  return trimV(v.split(CUT2)[0]);
}

var MONTHS = { jan: 1, feb: 2, mar: 3, apr: 4, may: 5, jun: 6, jul: 7, aug: 8, sep: 9, oct: 10, nov: 11, dec: 12 };
function pad2(n) { return (n < 10 ? '0' : '') + n; }
function ymd(y, m, d) {
  if (y < 100) y += y > 50 ? 1900 : 2000;
  if (m < 1 || m > 12 || d < 1 || d > 31) return '';
  return y + '-' + pad2(m) + '-' + pad2(d);
}
function parseDate(v) {
  if (!v) return '';
  var m;
  if ((m = /(\d{4})-(\d{1,2})-(\d{1,2})/.exec(v))) { var r = ymd(+m[1], +m[2], +m[3]); if (r) return r; }
  if ((m = /(\d{1,2})[\/.\-](\d{1,2})[\/.\-](\d{2,4})/.exec(v))) { var r2 = ymd(+m[3], +m[2], +m[1]); if (r2) return r2; }
  if ((m = /(\d{1,2})(?:st|nd|rd|th)?\s+([A-Za-z]{3,9})\.?,?\s+(\d{4})/.exec(v)) && MONTHS[m[2].slice(0, 3).toLowerCase()]) {
    return ymd(+m[3], MONTHS[m[2].slice(0, 3).toLowerCase()], +m[1]);
  }
  if ((m = /([A-Za-z]{3,9})\.?\s+(\d{1,2})(?:st|nd|rd|th)?,?\s+(\d{4})/.exec(v)) && MONTHS[m[1].slice(0, 3).toLowerCase()]) {
    return ymd(+m[3], MONTHS[m[1].slice(0, 3).toLowerCase()], +m[2]);
  }
  return String(v).slice(0, 30);
}

var PHONE_RE = '(?:\\+|00)?\\d[\\d\\s\\-()]{7,18}\\d';
var EID_RE = '784[\\s\\-]?\\d{4}[\\s\\-]?\\d{7}[\\s\\-]?\\d';
var WA_RE = '(?:whats\\s*app|واتس\\s*اب|واتساب)[ \\t]*(?:no\\.?|number|رقم)?[ \\t]*[:\\-–]?[ \\t]*(' + PHONE_RE + ')';

function getEmail(t) { var m = /[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}/.exec(t); return m ? m[0] : ''; }
function getWhatsapp(t) { var m = new RegExp(WA_RE, 'i').exec(t); return m ? m[1].replace(/\s+/g, ' ').trim() : ''; }
function getEmiratesId(t) {
  var m = new RegExp(EID_RE).exec(t); if (!m) return '';
  var d = m[0].replace(/\D/g, '');
  return d.slice(0, 3) + '-' + d.slice(3, 7) + '-' + d.slice(7, 14) + '-' + d.slice(14);
}
function getPhone(t) {
  t = t.replace(new RegExp(WA_RE, 'ig'), ' ').replace(new RegExp(EID_RE, 'g'), ' ');
  var re = new RegExp(PHONE_RE, 'g'), m;
  while ((m = re.exec(t))) {
    var v = m[0].replace(/\s+/g, ' ').trim(), digits = v.replace(/\D/g, '');
    if (/(19|20)\d{2}\s*[-–]\s*(19|20)\d{2}/.test(v)) continue;
    if (digits.length >= 9 && digits.length <= 15) return v;
  }
  return '';
}
function getDob(t) {
  return parseDate(labeled(t, ['Date of Birth', 'Birth Date', 'Birthdate', 'D.O.B', 'DOB', 'تاريخ الميلاد', 'تاريخ الولادة', 'الميلاد'], true, true));
}

var AR_NAT = { 'مصري': 'Egyptian', 'مصرية': 'Egyptian', 'سوري': 'Syrian', 'سورية': 'Syrian', 'أردني': 'Jordanian', 'اردني': 'Jordanian', 'أردنية': 'Jordanian', 'لبناني': 'Lebanese', 'لبنانية': 'Lebanese', 'فلسطيني': 'Palestinian', 'فلسطينية': 'Palestinian', 'عراقي': 'Iraqi', 'عراقية': 'Iraqi', 'سوداني': 'Sudanese', 'سودانية': 'Sudanese', 'يمني': 'Yemeni', 'يمنية': 'Yemeni', 'هندي': 'Indian', 'هندية': 'Indian', 'باكستاني': 'Pakistani', 'باكستانية': 'Pakistani', 'بنغالي': 'Bangladeshi', 'فلبيني': 'Filipino', 'فلبينية': 'Filipino', 'إماراتي': 'Emirati', 'اماراتي': 'Emirati', 'إماراتية': 'Emirati', 'سعودي': 'Saudi', 'سعودية': 'Saudi', 'مغربي': 'Moroccan', 'تونسي': 'Tunisian', 'جزائري': 'Algerian', 'ليبي': 'Libyan', 'كويتي': 'Kuwaiti', 'عماني': 'Omani', 'بحريني': 'Bahraini', 'قطري': 'Qatari' };
var EN_NAT = ['Egyptian', 'Syrian', 'Jordanian', 'Lebanese', 'Palestinian', 'Iraqi', 'Sudanese', 'Yemeni', 'Indian', 'Pakistani', 'Bangladeshi', 'Filipino', 'Emirati', 'Saudi', 'Moroccan', 'Tunisian', 'Algerian', 'Libyan', 'Kuwaiti', 'Omani', 'Bahraini', 'Qatari', 'Nepali', 'Sri Lankan', 'British', 'American', 'Canadian'];

function getNationality(t) {
  var v = labeled(t, ['Nationality', 'Citizenship', 'الجنسية', 'الجنسيه'], true), k;
  if (v) { for (k in AR_NAT) if (v.indexOf(k) >= 0) return AR_NAT[k]; return v.slice(0, 40); }
  for (var i = 0; i < EN_NAT.length; i++) if (new RegExp('\\b' + EN_NAT[i] + '\\b', 'i').test(t)) return EN_NAT[i];
  for (k in AR_NAT) if (new RegExp('(?<![\\u0600-\\u06FF])' + k + '(?![\\u0600-\\u06FF])').test(t)) return AR_NAT[k];
  return '';
}
function getGender(t) {
  var v = labeled(t, ['Gender', 'Sex', 'الجنس', 'النوع'], true, true).toLowerCase();
  if (v) { if (/female|أنثى|انثى/.test(v)) return 'Female'; if (/male|ذكر/.test(v)) return 'Male'; }
  if (/\bfemale\b|أنثى|انثى/i.test(t)) return 'Female';
  if (/\bmale\b|(?<![\u0600-\u06FF])ذكر(?![\u0600-\u06FF])/i.test(t)) return 'Male';
  return '';
}
function getEducation(t) {
  var v = labeled(t, ['Education', 'Academic Qualification', 'Qualification', 'المؤهل العلمي', 'المؤهل', 'التعليم', 'التحصيل العلمي']);
  if (v) return v.slice(0, 200);
  var keys = ['PhD', 'Ph.D', 'Doctorate', 'Master', 'M.Sc', 'MBA', 'Bachelor', 'B.Sc', 'BBA', 'Diploma', 'دكتوراه', 'ماجستير', 'بكالوريوس', 'دبلوم'];
  var lines = t.split('\n');
  for (var i = 0; i < lines.length; i++) for (var j = 0; j < keys.length; j++)
    if (lines[i].toLowerCase().indexOf(keys[j].toLowerCase()) >= 0) return lines[i].trim().slice(0, 200);
  return '';
}

var POS_KEYS = ['Chief', 'Director', 'Head', 'Manager', 'Supervisor', 'Officer', 'Specialist', 'Coordinator', 'Engineer', 'Consultant', 'Administrator', 'Executive', 'Accountant', 'Analyst', 'Technician', 'Driver', 'Welder', 'Chef', 'Nurse', 'Operator', 'Electrician', 'Plumber', 'Foreman', 'Surveyor', 'مدير', 'رئيس', 'مشرف', 'مسؤول', 'أخصائي', 'منسق', 'مهندس', 'استشاري', 'محاسب', 'فني', 'سائق', 'لحام', 'ممرض', 'طبيب'];
function hasPosKey(s) { s = s.toLowerCase(); return POS_KEYS.some(function (k) { return s.indexOf(k.toLowerCase()) >= 0; }); }

function getLastPosition(t) {
  var v = labeled(t, ['Current Position', 'Last Position', 'Job Title', 'Position', 'Designation', 'المسمى الوظيفي', 'آخر منصب', 'الوظيفة الحالية', 'المسمى']);
  if (v) return v.slice(0, 150);
  var lines = t.split('\n').slice(0, 30);
  for (var i = 0; i < lines.length; i++) {
    var s = lines[i].trim(), n = s.split(/\s+/).length;
    if (n >= 1 && n <= 8 && hasPosKey(s)) return s.slice(0, 150);
  }
  return '';
}
function getExperience(t) {
  var now = new Date().getFullYear(), spans = [];
  var re = /((?:19|20)\d{2})\s*(?:-|–|—|to|إلى|الى)\s*((?:19|20)\d{2}|present|current|now|till date|حتى الآن|حتى الان|الآن|الحالي|حاليا|حالياً|الان)/gi, m;
  while ((m = re.exec(t))) {
    var s = +m[1], e = /^\d/.test(m[2]) ? +m[2] : now;
    if (s >= 1970 && s <= e && e <= now) spans.push([s, e]);
  }
  if (spans.length) {
    spans.sort(function (a, b) { return a[0] - b[0]; });
    var total = 0, cs = spans[0][0], ce = spans[0][1];
    for (var i = 1; i < spans.length; i++) {
      if (spans[i][0] <= ce) ce = Math.max(ce, spans[i][1]); else { total += ce - cs; cs = spans[i][0]; ce = spans[i][1]; }
    }
    total += ce - cs;
    if (total > 0) return total;
  }
  var pats = [/(\d{1,2})\s*\+?\s*(?:years?|yrs?)/i, /(\d{1,2})\s*(?:سنة|سنوات|عام|أعوام)/, /خبرة\s*(\d{1,2})/];
  for (var j = 0; j < pats.length; j++) { var x = pats[j].exec(t); if (x) return +x[1]; }
  return '';
}
var HEADING_RE = /^(education|experience|work experience|skills|languages?|summary|objective|career objective|contact|personal|qualifications?|references?|certificates?|courses|projects|interests|hobbies|المؤهلات|الخبرات|الخبرة|المهارات|اللغات|الدورات|المراجع|الهوايات|التعليم)\b/i;
function getName(t) {
  var v = labeled(t, ['Full Name', 'Candidate Name', 'Name', 'الاسم الكامل', 'الاسم']);
  if (v) return v.slice(0, 100);
  var skip = ['curriculum vitae', 'resume', 'cv', 'السيرة الذاتية', 'personal information', 'personal details', 'المعلومات الشخصية', 'profile', 'summary'];
  var lines = t.split('\n').slice(0, 15);
  for (var i = 0; i < lines.length; i++) {
    var s = trimV(lines[i]);
    if (!s || skip.indexOf(s.toLowerCase()) >= 0 || s.indexOf('@') >= 0 || s.indexOf(':') >= 0 || /\d/.test(s) || s.length > 70 || HEADING_RE.test(s)) continue;
    var n = s.split(/\s+/).length;
    if (n >= 2 && n <= 6 && !hasPosKey(s)) return s;
  }
  return '';
}
function getPassportNo(t) {
  var v = labeled(t, ['Passport Number', 'Passport No', 'Passport #', 'Passport', 'رقم جواز السفر', 'رقم الجواز', 'جواز السفر'], true, true);
  var m = /\b(?=[A-Z0-9]*\d)[A-Z0-9]{6,12}\b/.exec(v.toUpperCase());
  return m ? m[0] : '';
}
function getPassportExpiry(t) {
  return parseDate(labeled(t, ['Passport Expiry Date', 'Passport Expiry', 'Passport Expires', 'Passport Valid Until', 'Passport Valid Till', 'تاريخ انتهاء جواز السفر', 'تاريخ انتهاء الجواز', 'انتهاء الجواز'], true, true));
}
var LIC_RE = /driv(?:ing|er'?s?)\s+licen[cs]e|رخصة\s*(?:ال)?قيادة/i;
function getLicenseType(t) {
  var lines = t.split('\n').map(function (l) { return l.trim(); });
  for (var i = 0; i < lines.length; i++) {
    if (!LIC_RE.test(lines[i]) || /computer|icdl|ecdl/i.test(lines[i])) continue;
    var segs = lines[i].split(/[|•●·;]/);
    for (var k = 0; k < segs.length; k++) {
      if (!LIC_RE.test(segs[k])) continue;
      var rest = segs[k].replace(new RegExp(LIC_RE.source, 'ig'), ' ').replace(/^[ :\-–*]+|[ :\-–*]+$/g, '');
      if (/[A-Za-z\u0600-\u06FF]{3,}/.test(rest) && segs[k].length <= 80 && segs[k].indexOf('@') < 0) return rest.slice(0, 80);
    }
    if (i + 1 < lines.length && /light vehicle|heavy|motorcycle|manual|automatic|class|category|\blmv\b|\bhmv\b|bus|truck|forklift|سيارة|ثقيل/i.test(lines[i + 1]) && lines[i + 1].length <= 80) return lines[i + 1].slice(0, 80);
  }
  return '';
}
function getLicenseExpiry(t) {
  return parseDate(labeled(t, ['Driving License Expiry', 'License Expiry Date', 'License Expiry', 'Licence Expiry', 'License Valid Until', 'تاريخ انتهاء رخصة القيادة', 'تاريخ انتهاء الرخصة', 'انتهاء الرخصة'], true, true));
}
var VISA_WORDS = ['Golden Visa', 'Employment Visa', 'Residence Visa', 'Resident Visa', 'Visit Visa', 'Tourist Visa', 'Family Visa', 'Freelance Visa', 'Student Visa', 'Cancelled Visa', 'Own Visa', 'Spouse Visa', 'Husband Visa', 'Mission Visa', 'إقامة ذهبية', 'إقامة عمل', 'إقامة عائلية', 'تأشيرة زيارة', 'تأشيرة سياحية', 'إقامة'];
function getVisa(t) {
  var v = labeled(t, ['Residency Status', 'Residence Status', 'Visa Status', 'Visa Type', 'Residency Type', 'Residency', 'Visa', 'نوع الإقامة', 'نوع الاقامة', 'حالة الإقامة', 'حالة التأشيرة', 'الإقامة'], true);
  if (v) return v.slice(0, 60);
  for (var i = 0; i < VISA_WORDS.length; i++) if (t.toLowerCase().indexOf(VISA_WORDS[i].toLowerCase()) >= 0) return VISA_WORDS[i];
  return '';
}
function getNotice(t) {
  var v = labeled(t, ['Notice Period', 'Availability', 'Available From', 'Joining Time', 'فترة الإشعار', 'فترة الاشعار', 'مدة الإشعار', 'مدة الاشعار'], true);
  if (v) return v.slice(0, 40);
  var m = /(\d+)\s*(day|week|month)s?\s*(?:of\s*)?notice/i.exec(t) || /notice(?:\s*period)?\s*(?:of|is)?\s*(\d+)\s*(day|week|month)s?/i.exec(t);
  if (m) return m[1] + ' ' + m[2].toLowerCase() + '(s)';
  if (/immediate(?:ly)?\s*(?:available|joiner|joining)|available immediately|فوري/i.test(t)) return 'Immediate';
  return '';
}
var PLACES = ['Abu Dhabi', 'Dubai', 'Sharjah', 'Ajman', 'Al Ain', 'Ras Al Khaimah', 'RAK', 'Fujairah', 'Umm Al Quwain', 'أبوظبي', 'أبو ظبي', 'دبي', 'الشارقة', 'عجمان', 'العين', 'رأس الخيمة', 'الفجيرة', 'أم القيوين'];
function getLocation(t) {
  var v = labeled(t, ['Current Location', 'Current Address', 'Home Address', 'Residential Address', 'Place of Residence', 'Residence', 'Location', 'City', 'مكان السكن', 'مكان الإقامة', 'السكن الحالي', 'العنوان', 'المدينة'], true);
  if (v && v.indexOf('@') < 0) return v.slice(0, 80);
  var head = t.split('\n').slice(0, 15).join('\n');
  for (var i = 0; i < PLACES.length; i++) if (new RegExp('(?<![A-Za-z])' + rxEsc(PLACES[i]) + '(?![A-Za-z])', 'i').test(head)) return PLACES[i];
  return '';
}

// ---- جديد: الراتب واللغات
function salaryNum(v) { var m = /\d[\d,]{2,8}/.exec(String(v).replace(/\s/g, '')); return m ? m[0].replace(/,/g, '') : ''; }
function getCurrentSalary(t) { return salaryNum(labeled(t, ['Current Salary', 'Present Salary', 'Current Monthly Salary', 'Last Salary', 'الراتب الحالي', 'آخر راتب'])); }
function getExpectedSalary(t) { return salaryNum(labeled(t, ['Expected Salary', 'Expected Monthly Salary', 'Salary Expectation', 'Desired Salary', 'الراتب المتوقع'])); }
var LANG_MAP = [['Arabic', /arabic|العربية/i], ['English', /english|الإنجليزية|الانجليزية/i], ['Hindi', /hindi|الهندية/i], ['Urdu', /urdu|الأردية|الاردية/i], ['Bengali', /bengali|bangla|البنغالية/i], ['Tagalog', /tagalog|filipino|الفلبينية/i], ['French', /french|الفرنسية/i], ['Russian', /russian|الروسية/i], ['Persian', /persian|farsi|الفارسية/i], ['Malayalam', /malayalam/i], ['Tamil', /tamil/i], ['Nepali', /nepali/i], ['Spanish', /spanish|الإسبانية/i], ['Turkish', /turkish|التركية/i]];
function getLanguages(t) {
  var m = /(?:languages?|اللغات)\s*[:\-]?\s*\n?([\s\S]{0,160})/i.exec(t);
  if (!m) return [];
  var seg = m[1], hits = [];
  LANG_MAP.forEach(function (p) { var i = seg.search(p[1]); if (i >= 0) hits.push([i, p[0]]); });
  hits.sort(function (a, b) { return a[0] - b[0]; });
  return hits.slice(0, 3).map(function (h) { return h[1]; });
}

/** يعيد سجلاً بأعمدة Candidates (الحقول غير الموجودة تبقى فارغة) */
function parseCv(t) {
  var langs = getLanguages(t);
  return {
    'Name': getName(t), 'Nationality': getNationality(t), 'Date of Birth': getDob(t), 'Gender': getGender(t),
    'Education': getEducation(t), 'Last Position': getLastPosition(t), 'Experience (Years)': getExperience(t),
    'Email': getEmail(t), 'Mobile': getPhone(t), 'WhatsApp': getWhatsapp(t), 'Current Location': getLocation(t),
    'Passport No.': getPassportNo(t), 'Passport Expiry': getPassportExpiry(t),
    'Driving License Type': getLicenseType(t), 'License Expiry': getLicenseExpiry(t),
    'Residency / Visa Type': getVisa(t), 'Emirates ID': getEmiratesId(t), 'Notice Period': getNotice(t),
    'Current Salary (AED)': getCurrentSalary(t), 'Expected Salary (AED)': getExpectedSalary(t),
    'Language 1': langs[0] || '', 'Language 2': langs[1] || '', 'Language 3': langs[2] || ''
  };
}
