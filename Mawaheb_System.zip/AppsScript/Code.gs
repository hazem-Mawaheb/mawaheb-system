/**
 * Mawaheb - قاعدة بيانات موحدة للباحثين عن عمل (Google Sheets)
 * المصادر: 1) نموذج الموقع  2) السير الواردة بالبريد (Gmail)  3) مجلد cvs عبر Python (sync.py)
 * الأدوات: MATCH / SHORTLIST / CLEAN من قائمة Mawaheb في الجدول.
 */
var SH = { HRREQ: 'HR_Requests', CAND: 'Candidates', TEXT: 'CV_Text', JOBS: 'Jobs', FILT: 'Filters', COMP: 'Companies', REV: 'Needs_Review', REM: 'Removed_Duplicates', TITLES: 'Titles', LOG: 'Log', SUM: 'Matching_Summary' };

var COLS = ['Candidate ID', 'Name', 'Nationality', 'Date of Birth', 'Gender', 'Education', 'Last Position', 'Experience (Years)',
  'Email', 'Mobile', 'WhatsApp', 'Current Location', 'Passport No.', 'Passport Expiry', 'Driving License Type', 'License Expiry',
  'Residency / Visa Type', 'Emirates ID', 'Notice Period', 'Source File', 'Notes',
  'Sector', 'Target Position', 'Job Category', 'Current Salary (AED)', 'Expected Salary (AED)', 'Language 1', 'Language 2', 'Language 3',
  'Mobile Abroad', 'Source', 'Date Added', 'Consent'];
var JOB_COLS = ['Job Title', 'Field Keywords (comma separated)', 'Industry / Activity (comma separated)', 'General Keywords (comma separated)', 'ERP & Systems (comma separated)', 'Min Experience (Years)', 'Max Experience (Years)', 'Min Education (Diploma/Bachelor/Master/PhD)', 'Location (optional)'];
var F_COLS = ['Shortlist Name', 'Job Title (from Jobs, optional)', 'Top N', 'Min Score (0-100)', 'Min Experience (Years)', 'Max Experience (Years)', 'Min Education (Diploma/Bachelor/Master/PhD)', 'Nationality (comma separated, optional)', 'Location contains (optional)', 'Max Expected Salary (AED)', 'Languages (comma separated, all required)', 'Sector (optional)'];
var COMP_COLS = ['Received', 'Company_Name', 'Mobile_No', 'Whatsapp_No', 'Email_ID', 'Site_Work_Location', 'Man_Power_Type', 'Position', 'Quantity', 'Visa_Status', 'Gross_Salary', 'Other_Benefits', 'Working_Hours', 'Holiday_Days'];
var FORM_MAP = { Full_Name: 'Name', Nationality: 'Nationality', Passport_No: 'Passport No.', Emirates_ID: 'Emirates ID', Mobile_No: 'Mobile', Mobile_Abroad: 'Mobile Abroad', Whatsapp_No: 'WhatsApp', Email: 'Email', Job_Category: 'Job Category', Education: 'Education', Sector: 'Sector', Target_Position: 'Target Position', Current_Salary: 'Current Salary (AED)', Expected_Salary: 'Expected Salary (AED)', Language_1: 'Language 1', Language_2: 'Language 2', Language_3: 'Language 3', Consent: 'Consent' };
var HR_COLS = ['Received', 'Company', 'Contact Name', 'Mobile', 'Email', 'Employees', 'Package', 'Message', 'Language'];
var NOTIFY_TO = 'mawaheb.uae@outlook.com';
/** يمنع تنفيذ المعادلات إذا بدأ النص بـ = + - @ (حماية من حقن المعادلات) */
function safeCell(v) { v = String(v == null ? '' : v).slice(0, 2000); return /^[=+\-@]/.test(v) ? "'" + v : v; }
var OWN_SENDERS = /mawaheb\.uae@outlook\.com|no-?reply|mailer-daemon|postmaster/i;

// ------------------------------------------------------------------ القائمة
function onOpen() {
  SpreadsheetApp.getUi().createMenu('Mawaheb')
    .addItem('1) تجهيز الجدول (Setup)', 'setupAll')
    .addSeparator()
    .addItem('استيراد السير من البريد الآن', 'importCvEmails')
    .addItem('تشغيل الاستيراد التلقائي كل 15 دقيقة', 'installEmailTrigger')
    .addSeparator()
    .addItem('MATCH: مطابقة وأفضل 7 مرشحين لكل وظيفة', 'runMatch')
    .addItem('SHORTLIST: القوائم المختصرة من Filters', 'runShortlist')
    .addItem('CLEAN: تنظيف ودمج المكرر', 'runClean')
    .addSeparator()
    .addItem('إعادة مكتبة المسميات للوضع الافتراضي', 'resetTitlesSheet')
    .addItem('إظهار رمز الربط TOKEN (لبرنامج Python)', 'showToken')
    .addToUi();
}

// ------------------------------------------------------------------ أدوات الجداول
function getSheet(name) { var ss = SpreadsheetApp.getActive(); return ss.getSheetByName(name) || ss.insertSheet(name); }
function styleHeader(sh, n) { sh.getRange(1, 1, 1, n).setBackground(HDR_BG).setFontColor('#FFFFFF').setFontWeight('bold').setHorizontalAlignment('center').setVerticalAlignment('middle').setWrap(true); sh.setFrozenRows(1); sh.setRowHeight(1, 34); }
function ensureHeaders(sh, cols) {
  var n = sh.getLastColumn(), cur = n ? sh.getRange(1, 1, 1, n).getValues()[0].map(String) : [];
  if (!cur.length || !cur[0]) { sh.getRange(1, 1, 1, cols.length).setValues([cols]); styleHeader(sh, cols.length); return cols.slice(); }
  var add = cols.filter(function (c) { return cur.indexOf(c) < 0; });
  if (add.length) { sh.getRange(1, cur.length + 1, 1, add.length).setValues([add]); cur = cur.concat(add); styleHeader(sh, cur.length); }
  return cur;
}
function readTable(name) {
  var sh = SpreadsheetApp.getActive().getSheetByName(name);
  if (!sh || sh.getLastRow() < 2) return { sheet: sh, headers: sh && sh.getLastColumn() ? sh.getRange(1, 1, 1, sh.getLastColumn()).getValues()[0].map(String) : [], rows: [] };
  var v = sh.getRange(1, 1, sh.getLastRow(), sh.getLastColumn()).getValues(), h = v[0].map(String), rows = [];
  for (var i = 1; i < v.length; i++) {
    var o = {}, any = false;
    h.forEach(function (k, j) { var x = v[i][j]; o[k] = x == null ? '' : String(x); if (o[k].trim()) any = true; });
    if (any) rows.push(o);
  }
  return { sheet: sh, headers: h, rows: rows };
}
function readTextMap() {
  var sh = SpreadsheetApp.getActive().getSheetByName(SH.TEXT), m = {};
  if (!sh || sh.getLastRow() < 2) return m;
  sh.getRange(2, 1, sh.getLastRow() - 1, 3).getValues().forEach(function (r) { if (r[0]) m[String(r[0])] = String(r[2] || ''); });
  return m;
}
function log(msg) {
  try {
    var sh = getSheet(SH.LOG);
    if (!sh.getLastRow()) sh.appendRow(['Time', 'Message']);
    sh.appendRow([new Date(), String(msg).slice(0, 500)]);
    if (sh.getLastRow() > 1500) sh.deleteRows(2, 700);
  } catch (e) {}
}
function today() { return Utilities.formatDate(new Date(), 'Asia/Dubai', 'yyyy-MM-dd'); }
function json(o) { return ContentService.createTextOutput(JSON.stringify(o)).setMimeType(ContentService.MimeType.JSON); }
function last9(v) { var d = String(v || '').replace(/\D/g, ''); return d.length >= 9 ? d.slice(-9) : ''; }

// ------------------------------------------------------------------ Setup
function setupAll() {
  var cs = getSheet(SH.CAND), hdr = ensureHeaders(cs, COLS);
  cs.getRange(1, 1, cs.getMaxRows(), hdr.length).setNumberFormat('@');
  var w = { 'Candidate ID': 14, 'Name': 26, 'Education': 36, 'Last Position': 28, 'Target Position': 28, 'Email': 30, 'Notes': 36, 'Source File': 24 };
  hdr.forEach(function (h, i) { cs.setColumnWidth(i + 1, (w[h] || 16) * 7); });
  cs.setFrozenColumns(2);
  if (!cs.getFilter()) cs.getRange(1, 1, Math.max(cs.getLastRow(), 2), hdr.length).createFilter();

  var ts = getSheet(SH.TEXT); ensureHeaders(ts, ['Candidate ID', 'Source File', 'CV Text']); ts.setColumnWidth(3, 500);

  var js = getSheet(SH.JOBS); ensureHeaders(js, JOB_COLS);
  if (js.getLastRow() < 2) {
    js.appendRow(['HR Manager', 'Organizational Transformation, Workforce Planning, Succession Planning', 'Oil & Gas, Energy & Industrial Services, Construction & Infrastructure, Heavy Equipment, Real Estate', 'Governance & Compliance, Compensation & Payroll', 'SAP, Oracle, Odoo, MenaPay', 7, '', 'Bachelor', 'Abu Dhabi']);
    js.getRange(2, 1, 1, JOB_COLS.length).setFontColor('#0000FF');
  }
  [22, 38, 32, 36, 26, 16, 16, 24, 18].forEach(function (x, i) { js.setColumnWidth(i + 1, x * 7); });

  var fs = getSheet(SH.FILT); ensureHeaders(fs, F_COLS);
  if (fs.getLastRow() < 2) {
    fs.appendRow(['HR Manager - Top 7', 'HR Manager', 7, 60, 5, '', 'Bachelor', '', 'Abu Dhabi', '', 'English', '']);
    fs.getRange(2, 1, 1, F_COLS.length).setFontColor('#0000FF');
  }
  [28, 30, 9, 14, 16, 16, 26, 30, 24, 16, 26, 20].forEach(function (x, i) { fs.setColumnWidth(i + 1, x * 7); });

  var ms = getSheet(SH.COMP); ensureHeaders(ms, COMP_COLS);
  ensureHeaders(getSheet(SH.HRREQ), HR_COLS);
  var tl = getSheet(SH.TITLES); if (tl.getLastRow() < 2) writeTitlesSheet_();
  getSheet(SH.LOG);

  var p = PropertiesService.getScriptProperties();
  if (!p.getProperty('TOKEN')) p.setProperty('TOKEN', Utilities.getUuid().replace(/-/g, ''));
  SpreadsheetApp.getUi().alert('تم تجهيز الجدول.\n\nرمز الربط TOKEN (انسخه إلى config.json في برنامج Python):\n' + p.getProperty('TOKEN') +
    '\n\nالخطوة التالية: Deploy > Manage deployments > Edit > New version (حتى يبقى رابط الموقع كما هو).');
}
function showToken() { SpreadsheetApp.getUi().alert('TOKEN:\n' + (PropertiesService.getScriptProperties().getProperty('TOKEN') || 'شغّل Setup أولاً')); }

// ------------------------------------------------------------------ مكتبة المسميات
function writeTitlesSheet_() {
  var sh = getSheet(SH.TITLES), lib = getTitlesLib(), rows = [];
  SECTORS.forEach(function (s) { (lib[s[0]] || []).forEach(function (t) { rows.push([s[0], s[1], s[2], t[0], t[1]]); }); });
  sh.clear();
  sh.getRange(1, 1, 1, 5).setValues([['Sector ID', 'Sector (AR)', 'Sector (EN)', 'Title (EN)', 'Title (AR)']]); styleHeader(sh, 5);
  sh.getRange(2, 1, rows.length, 5).setValues(rows);
  [14, 26, 26, 34, 34].forEach(function (x, i) { sh.setColumnWidth(i + 1, x * 7); });
  CacheService.getScriptCache().remove('titles');
}
function resetTitlesSheet() {
  var ui = SpreadsheetApp.getUi();
  if (ui.alert('سيُستبدل محتوى ورقة Titles بالمكتبة الافتراضية وتضيع تعديلاتك. متابعة؟', ui.ButtonSet.YES_NO) === ui.Button.YES) writeTitlesSheet_();
}
/** المكتبة التي يقرأها الموقع: من ورقة Titles (قابلة للتعديل) وإلا الافتراضية */
function titlesForSite() {
  var cache = CacheService.getScriptCache(), c = cache.get('titles');
  if (c) return JSON.parse(c);
  var sh = SpreadsheetApp.getActive().getSheetByName(SH.TITLES), lib = {};
  if (sh && sh.getLastRow() > 1) {
    sh.getRange(2, 1, sh.getLastRow() - 1, 5).getValues().forEach(function (r) {
      var id = String(r[0]).trim(), en = String(r[3]).trim(); if (!id || !en) return;
      (lib[id] = lib[id] || []).push([en, String(r[4]).trim()]);
    });
  } else lib = getTitlesLib();
  try { cache.put('titles', JSON.stringify(lib), 600); } catch (e) {}
  return lib;
}

// ------------------------------------------------------------------ نقاط الاستقبال (الموقع + Python)
function doGet(e) {
  var a = e && e.parameter && e.parameter.action;
  if (a === 'titles') return json(titlesForSite());
  return json({ ok: true, service: 'Mawaheb DB' });
}
function doPost(e) {
  try {
    var c = (e.postData && e.postData.contents) || '';
    if (c.charAt(0) === '{') return json(handleApi(JSON.parse(c)));
    return json(handleForm(e.parameter || {}));
  } catch (err) { log('doPost: ' + err); return json({ ok: false, error: String(err) }); }
}
function handleForm(p) {
  if (p._gotcha) return { ok: true };
  if (p.form_type === 'Candidate_Registration') {
    var rec = {};
    Object.keys(FORM_MAP).forEach(function (k) { if (p[k] != null && String(p[k]).trim() !== '') rec[FORM_MAP[k]] = String(p[k]).trim(); });
    upsertMany([rec], { mode: 'form', source: 'Website' });
    return { ok: true };
  }
  if (p.form_type === 'Client_Order') {
    var sh = getSheet(SH.COMP), hdr = ensureHeaders(sh, COMP_COLS), row = hdr.map(function (h) { return h === 'Received' ? new Date() : (p[h] != null ? safeCell(p[h]) : ''); });
    sh.appendRow(row);
    return { ok: true };
  }
  if (p.form_type === 'HR_Consultation') return handleHrRequest(p);
  return { ok: false, error: 'unknown form' };
}
/** طلب استشارة موارد بشرية من الموقع: يُحفظ في HR_Requests ويصل إلى البريد */
function handleHrRequest(p) {
  var company = String(p.Company_Name || '').trim(), name = String(p.Contact_Name || '').trim(), mobile = String(p.Mobile_No || '').trim(), email = String(p.Email_ID || '').trim();
  if (!company || !name || !mobile || !email) return { ok: false, error: 'missing fields' };
  var sh = getSheet(SH.HRREQ), hdr = ensureHeaders(sh, HR_COLS);
  var vals = { 'Received': new Date(), 'Company': safeCell(company), 'Contact Name': safeCell(name), 'Mobile': safeCell(mobile), 'Email': safeCell(email), 'Employees': safeCell(p.Employees), 'Package': safeCell(p.Package), 'Message': safeCell(p.Message), 'Language': safeCell(p.Lang) };
  sh.appendRow(hdr.map(function (h) { return vals[h] != null ? vals[h] : ''; }));
  try {
    var body = ['New HR consultation request', '', 'Company: ' + company, 'Contact: ' + name, 'Mobile: ' + mobile, 'Email: ' + email,
      'Employees: ' + (p.Employees || '-'), 'Package: ' + (p.Package || '-'), 'Message: ' + (p.Message || '-'), '', 'WhatsApp: https://wa.me/' + mobile.replace(/\D/g, '')].join('\n');
    var opt = { to: NOTIFY_TO, subject: 'HR consultation request - ' + company.slice(0, 80), body: body, name: 'Mawaheb website' };
    if (/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) opt.replyTo = email;
    MailApp.sendEmail(opt);
  } catch (err) { log('HR mail: ' + err); }
  return { ok: true };
}
function handleApi(d) {
  var tok = PropertiesService.getScriptProperties().getProperty('TOKEN');
  if (!tok || d.token !== tok) return { ok: false, error: 'bad token' };
  if (d.action === 'ping') return { ok: true };
  if (d.action === 'upsert') {
    var res = upsertMany(d.records || [], { mode: 'cv', source: d.source || 'Folder', texts: d.texts || {} });
    return { ok: true, results: res };
  }
  return { ok: false, error: 'unknown action' };
}

// ------------------------------------------------------------------ الدمج في Candidates
function loadCand() {
  var sh = getSheet(SH.CAND), hdr = ensureHeaders(sh, COLS), ix = {};
  hdr.forEach(function (h, i) { ix[h] = i; });
  var last = sh.getLastRow(), data = last > 1 ? sh.getRange(2, 1, last - 1, hdr.length).getValues().map(function (r) { return r.map(function (v) { return v == null ? '' : String(v); }); }) : [];
  return { sh: sh, hdr: hdr, ix: ix, data: data };
}
function saveCand(ctx, data) {
  var sh = ctx.sh, old = sh.getLastRow() - 1;
  if (old > 0) sh.getRange(2, 1, old, ctx.hdr.length).clearContent();
  if (data.length) {
    if (sh.getMaxRows() < data.length + 1) sh.insertRowsAfter(sh.getMaxRows(), data.length + 1 - sh.getMaxRows());
    sh.getRange(2, 1, data.length, ctx.hdr.length).setNumberFormat('@').setValues(data);
  }
}
function enrichFromText(rec, text) {
  if (!rec['Current Salary (AED)']) rec['Current Salary (AED)'] = getCurrentSalary(text);
  if (!rec['Expected Salary (AED)']) rec['Expected Salary (AED)'] = getExpectedSalary(text);
  if (!rec['Language 1']) { var l = getLanguages(text); rec['Language 1'] = l[0] || ''; rec['Language 2'] = l[1] || ''; rec['Language 3'] = l[2] || ''; }
}
function addNote(row, ix, note) {
  if (!note) return;
  var cur = row[ix['Notes']];
  if (cur.indexOf(note) >= 0) return;
  row[ix['Notes']] = cur ? cur + '; ' + note : note;
}

/** recs: كائنات بأسماء أعمدة Candidates. mode: form = بيانات المرشح تُحدّث، cv = تُملأ الفراغات فقط */
function upsertMany(recs, opts) {
  var lock = LockService.getScriptLock(); lock.waitLock(30000);
  try {
    var ctx = loadCand(), ix = ctx.ix, data = ctx.data, texts = opts.texts || {}, results = [];
    var byE = {}, byM = {}, byS = {}, maxN = 0;
    var idx = function (r, i) {
      var e = r[ix['Email']].trim().toLowerCase(), m = last9(r[ix['Mobile']]), s = r[ix['Source File']].trim();
      if (e) byE[e] = i; if (m) byM[m] = i; if (s) byS[s] = i;
      var mm = /^CAN-(\d+)$/.exec(r[ix['Candidate ID']]); if (mm) maxN = Math.max(maxN, +mm[1]);
    };
    data.forEach(idx);
    var tsh = getSheet(SH.TEXT), tvals = tsh.getLastRow() > 1 ? tsh.getRange(2, 1, tsh.getLastRow() - 1, 3).getValues() : [], tix = {};
    tvals.forEach(function (r, i) { tix[r[0]] = i; });
    var textChanged = false;

    recs.forEach(function (rec) {
      var src = String(rec['Source File'] || '').trim(), txt = src && texts[src] ? String(texts[src]).slice(0, 45000) : '';
      if (txt) enrichFromText(rec, txt);
      var e = String(rec['Email'] || '').trim().toLowerCase(), m = last9(rec['Mobile']);
      var i = (e && byE[e] != null) ? byE[e] : (m && byM[m] != null) ? byM[m] : (src && byS[src] != null) ? byS[src] : -1, row, status;
      if (i < 0) {
        row = ctx.hdr.map(function () { return ''; }); status = 'added';
        row[ix['Candidate ID']] = 'CAN-' + ('0000' + (++maxN)).slice(-4);
        row[ix['Date Added']] = today(); row[ix['Source']] = opts.source || '';
        data.push(row); i = data.length - 1;
        if (opts.mode === 'form') row[ix['Notes']] = 'Awaiting CV';
      } else { row = data[i]; status = 'merged'; }
      COLS.forEach(function (c) {
        if (c === 'Candidate ID' || c === 'Date Added' || c === 'Source') return;
        var v = rec[c]; if (v == null || String(v).trim() === '') return; v = String(v).trim();
        if (c === 'Notes') { addNote(row, ix, v); return; }
        if (c === 'Source File' && row[ix[c]] && row[ix[c]] !== v) { addNote(row, ix, 'Also CV: ' + v); return; }
        if (opts.mode === 'form' || !row[ix[c]]) row[ix[c]] = v;
      });
      if (opts.mode !== 'form' && src) row[ix['Notes']] = row[ix['Notes']].replace(/(?:;\s*)?Awaiting CV/, '').replace(/^;\s*/, '');
      if (opts.source && status === 'merged' && row[ix['Source']].indexOf(opts.source) < 0) row[ix['Source']] += (row[ix['Source']] ? ' + ' : '') + opts.source;
      idx(row, i);
      if (txt) {
        var id = row[ix['Candidate ID']];
        if (tix[id] != null) { if (!tvals[tix[id]][2]) tvals[tix[id]] = [id, src, txt]; }
        else { tvals.push([id, src, txt]); tix[id] = tvals.length - 1; }
        textChanged = true;
      }
      results.push({ file: src, id: row[ix['Candidate ID']], status: status });
    });
    saveCand(ctx, data);
    if (textChanged) {
      if (tsh.getLastRow() > 1) tsh.getRange(2, 1, tsh.getLastRow() - 1, 3).clearContent();
      tsh.getRange(2, 1, tvals.length, 3).setNumberFormat('@').setValues(tvals);
    }
    return results;
  } finally { lock.releaseLock(); }
}

// ------------------------------------------------------------------ استيراد السير من Gmail
function extractText(blob) {
  var f = Drive.Files.create({ name: 'tmp_cv_' + Date.now(), mimeType: 'application/vnd.google-apps.document' }, blob);
  try { return cvClean(DocumentApp.openById(f.id).getBody().getText()); }
  finally { try { Drive.Files.remove(f.id); } catch (e) {} }
}
function getLabel(n) { return GmailApp.getUserLabelByName(n) || GmailApp.createLabel(n); }

function importCvEmails() {
  var t0 = Date.now(), done = getLabel('CV_DONE'), me = Session.getEffectiveUser().getEmail(), added = 0, merged = 0, files = 0;
  var q = 'in:inbox has:attachment -label:CV_DONE newer_than:60d (filename:pdf OR filename:docx OR filename:jpg OR filename:jpeg OR filename:png)';
  var threads = GmailApp.search(q, 0, 25);
  for (var t = 0; t < threads.length; t++) {
    if (Date.now() - t0 > 270000) break;
    var msgs = threads[t].getMessages();
    for (var m = 0; m < msgs.length; m++) {
      var atts = msgs[m].getAttachments({ includeInlineImages: false });
      for (var a = 0; a < atts.length; a++) {
        var att = atts[a], nm = att.getName(), ext = (nm.split('.').pop() || '').toLowerCase();
        if (['pdf', 'docx', 'jpg', 'jpeg', 'png'].indexOf(ext) < 0 || att.getSize() > 10 * 1024 * 1024) continue;
        var rec, text = '';
        try { text = extractText(att); } catch (err) { log('extract ' + nm + ': ' + err); }
        files++;
        if (text.length < 80) { rec = { 'Source File': nm, 'Notes': 'No readable text - check the attachment' }; }
        else rec = parseCv(text);
        rec['Source File'] = nm;
        if (!rec['Email']) {
          var s = getEmail(msgs[m].getFrom());
          if (s && s.toLowerCase() !== me.toLowerCase() && !OWN_SENDERS.test(s)) { rec['Email'] = s; rec['Notes'] = (rec['Notes'] ? rec['Notes'] + '; ' : '') + 'Email taken from sender - verify'; }
        }
        var texts = {}; if (text.length >= 80) texts[nm] = text;
        var res = upsertMany([rec], { mode: 'cv', source: 'Gmail', texts: texts });
        if (res[0].status === 'added') added++; else merged++;
      }
    }
    threads[t].addLabel(done);
  }
  var msg = 'Gmail import: ' + files + ' file(s), ' + added + ' new, ' + merged + ' merged';
  log(msg);
  // بعد وصول سير جديدة: أعد المطابقة تلقائياً لتُحدَّث ورقة Top_7 (إن بقي وقت كافٍ)
  if (added + merged > 0 && Date.now() - t0 < 150000 && SpreadsheetApp.getActive().getSheetByName(SH.JOBS) && readJobs().length) {
    try { runMatch(true); msg += ' | Top_7 updated'; } catch (err) { log('auto match: ' + err); }
  }
  try { SpreadsheetApp.getUi().alert(msg); } catch (e) {}
}
function installEmailTrigger() {
  ScriptApp.getProjectTriggers().forEach(function (t) { if (t.getHandlerFunction() === 'importCvEmails') ScriptApp.deleteTrigger(t); });
  ScriptApp.newTrigger('importCvEmails').timeBased().everyMinutes(15).create();
  SpreadsheetApp.getUi().alert('تم تشغيل الاستيراد التلقائي: كل 15 دقيقة تُقرأ السير الجديدة في صندوق الوارد (PDF / Word / صور).');
}

// ------------------------------------------------------------------ CLEAN
var REQUIRED = ['Name', 'Email', 'Mobile'];
function runClean() {
  var ui = SpreadsheetApp.getUi(), ctx = loadCand(), ix = ctx.ix, data = ctx.data;
  if (!data.length) return ui.alert('ورقة Candidates فارغة.');
  var changed = 0;
  data.forEach(function (r) {
    for (var c = 0; c < r.length; c++) { var n = r[c].replace(/\s+/g, ' ').trim(); if (n !== r[c]) { changed++; r[c] = n; } }
    var low = r[ix['Email']].toLowerCase(); if (low !== r[ix['Email']]) { changed++; r[ix['Email']] = low; }
    var nm = r[ix['Name']];
    if (/[A-Za-z]/.test(nm) && !/[\u0600-\u06FF]/.test(nm) && (nm === nm.toUpperCase() || nm === nm.toLowerCase())) { r[ix['Name']] = nm.toLowerCase().replace(/(^|[\s\-'])([a-z])/g, function (x, a, b) { return a + b.toUpperCase(); }); changed++; }
  });
  // مكرر: نفس البريد أو نفس آخر 9 أرقام من الموبايل
  var parent = data.map(function (_, i) { return i; }), find = function (x) { while (parent[x] !== x) { parent[x] = parent[parent[x]]; x = parent[x]; } return x; }, seen = {};
  data.forEach(function (r, i) {
    var ks = []; if (r[ix['Email']]) ks.push('e:' + r[ix['Email']]); if (last9(r[ix['Mobile']])) ks.push('m:' + last9(r[ix['Mobile']]));
    ks.forEach(function (k) { if (seen[k] != null) parent[find(i)] = find(seen[k]); else seen[k] = i; });
  });
  var groups = {}; data.forEach(function (_, i) { (groups[find(i)] = groups[find(i)] || []).push(i); });
  var dups = Object.keys(groups).map(function (k) { return groups[k]; }).filter(function (g) { return g.length > 1; });
  var drop = {}, removed = [], msg = 'تم تنظيف ' + changed + ' خلية.\n';
  if (dups.length) {
    var list = dups.slice(0, 12).map(function (g) { return g.map(function (i) { return data[i][ix['Candidate ID']] + ' (' + data[i][ix['Name']] + ')'; }).join('  =  '); }).join('\n');
    if (ui.alert('وُجدت ' + dups.length + ' مجموعة مكررة:\n\n' + list + (dups.length > 12 ? '\n...' : '') + '\n\nدمج كل مجموعة في سجل واحد؟', ui.ButtonSet.YES_NO) === ui.Button.YES) {
      var texts = readTextMap(), tchg = false;
      dups.forEach(function (g) {
        var filled = function (i) { return data[i].filter(String).length; };
        g.sort(function (a, b) { return (filled(b) - filled(a)) || String(data[a][ix['Candidate ID']]).localeCompare(data[b][ix['Candidate ID']]); });
        var keep = data[g[0]], ids = [];
        g.slice(1).forEach(function (o) {
          COLS.forEach(function (c) { if (['Notes', 'Source File', 'Candidate ID'].indexOf(c) < 0 && !keep[ix[c]] && data[o][ix[c]]) keep[ix[c]] = data[o][ix[c]]; });
          var oid = data[o][ix['Candidate ID']], kid = keep[ix['Candidate ID']];
          if (texts[oid] && !texts[kid]) { texts[kid] = texts[oid]; tchg = true; }
          ids.push(oid); removed.push(data[o].slice()); drop[o] = 1;
        });
        addNote(keep, ix, 'Merged duplicates: ' + ids.join(', '));
      });
      if (tchg) { var tsh = getSheet(SH.TEXT), tv = Object.keys(texts).map(function (id) { return [id, '', texts[id]]; }); tsh.getRange(2, 1, Math.max(tsh.getMaxRows() - 1, 1), 3).clearContent(); tsh.getRange(2, 1, tv.length, 3).setNumberFormat('@').setValues(tv); }
      msg += 'تم دمج ' + removed.length + ' سجل مكرر (محفوظة في Removed_Duplicates).\n';
    } else msg += 'تُركت المكررات كما هي.\n';
  } else msg += 'لا توجد مكررات.\n';
  var out = data.filter(function (_, i) { return !drop[i]; });
  var review = [];
  out.forEach(function (r) {
    r[ix['Notes']] = r[ix['Notes']].replace(/(?:;\s*)?Incomplete: [^;]*/g, '').replace(/^[ ;]+|[ ;]+$/g, '');
    var miss = REQUIRED.filter(function (c) { return !r[ix[c]]; });
    if (!r[ix['Last Position']] && !r[ix['Target Position']]) miss.push('Position');
    if (miss.length) { addNote(r, ix, 'Incomplete: ' + miss.join(', ')); review.push(r); }
  });
  out.sort(function (a, b) { return String(a[ix['Candidate ID']]).localeCompare(b[ix['Candidate ID']]); });
  saveCand(ctx, out);
  if (removed.length) { var rs = getSheet(SH.REM); ensureHeaders(rs, ctx.hdr); rs.getRange(rs.getLastRow() + 1, 1, removed.length, ctx.hdr.length).setNumberFormat('@').setValues(removed); }
  var rv = getSheet(SH.REV); rv.clear(); rv.getRange(1, 1, 1, ctx.hdr.length).setValues([ctx.hdr]); styleHeader(rv, ctx.hdr.length);
  if (review.length) rv.getRange(2, 1, review.length, ctx.hdr.length).setNumberFormat('@').setValues(review);
  msg += 'سجلات ناقصة: ' + review.length + ' (ورقة Needs_Review).';
  ui.alert(msg);
}
