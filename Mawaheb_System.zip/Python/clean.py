# -*- coding: utf-8 -*-
"""
Clean CV_Master.xlsx:
  1. tidy text (spaces, e-mail case, ALL-CAPS / all-lowercase Latin names)
  2. find duplicate candidates (same e-mail or same mobile) and merge them - ONLY after you confirm
  3. flag incomplete records (Notes column) and list them in output/Needs_Review.xlsx
Missing data is never invented. A backup of the Excel file is made first.
"""
from datetime import datetime
from pathlib import Path
import re
import shutil

import pandas as pd

from main import COLUMNS, OUT_DIR, OUT_FILE, format_excel

REQUIRED = ["Name", "Email", "Mobile", "Last Position", "Experience (Years)"]
LOG = OUT_DIR / "processed_files.txt"


def filled(row):
    return sum(1 for c in COLUMNS if str(row[c]).strip())


def last9(v):
    d = re.sub(r"\D", "", str(v))
    return d[-9:] if len(d) >= 9 else ""


def find_groups(df):
    parent = list(range(len(df)))

    def find(x):
        while parent[x] != x:
            parent[x] = parent[parent[x]]
            x = parent[x]
        return x

    seen = {}
    for i, r in df.iterrows():
        keys = []
        if r["Email"].strip():
            keys.append("e:" + r["Email"].strip().lower())
        if last9(r["Mobile"]):
            keys.append("m:" + last9(r["Mobile"]))
        for k in keys:
            if k in seen:
                parent[find(i)] = find(seen[k])
            else:
                seen[k] = i
    groups = {}
    for i in range(len(df)):
        groups.setdefault(find(i), []).append(i)
    return [g for g in groups.values() if len(g) > 1]


def main():
    if not OUT_FILE.exists():
        print("output\\CV_Master.xlsx not found. Run START.bat first.")
        return
    try:
        df = pd.read_excel(OUT_FILE, dtype=str).fillna("")
    except PermissionError:
        print("Please close CV_Master.xlsx, then run CLEAN.bat again.")
        return
    for c in COLUMNS:
        if c not in df.columns:
            df[c] = ""
    df = df[COLUMNS].copy()

    # 1) tidy
    changed = 0
    for c in COLUMNS:
        new = df[c].map(lambda v: re.sub(r"\s+", " ", str(v)).strip())
        changed += int((new != df[c]).sum())
        df[c] = new
    low = df["Email"].str.lower()
    changed += int((low != df["Email"]).sum())
    df["Email"] = low

    def fix_name(n):
        if re.search(r"[A-Za-z]", n) and not re.search(r"[\u0600-\u06FF]", n) and (n.isupper() or n.islower()):
            return n.title()
        return n
    new = df["Name"].map(fix_name)
    changed += int((new != df["Name"]).sum())
    df["Name"] = new
    print("Text tidied in %d cell(s)." % changed)

    # 2) duplicates
    groups = find_groups(df)
    removed_ids, removed_rows, removed_files = [], [], []
    if groups:
        print("\nFound %d duplicate group(s):" % len(groups))
        for g in groups:
            print("   " + "  =  ".join("%s (%s)" % (df.loc[i, "Candidate ID"], df.loc[i, "Name"]) for i in g))
        ans = input("\nMerge each group into one record? Type Y then Enter (anything else = skip): ").strip().lower()
        if ans == "y":
            drop = []
            for g in groups:
                g_sorted = sorted(g, key=lambda i: (-filled(df.loc[i]), df.loc[i, "Candidate ID"]))
                keep, others = g_sorted[0], g_sorted[1:]
                for o in others:
                    for c in COLUMNS:
                        if not df.loc[keep, c] and df.loc[o, c] and c not in ("Notes", "Source File"):
                            df.loc[keep, c] = df.loc[o, c]
                    removed_rows.append(df.loc[o].copy())
                    removed_ids.append(df.loc[o, "Candidate ID"])
                    removed_files.append(df.loc[o, "Source File"])
                    drop.append(o)
                note = "Merged duplicates: " + ", ".join(df.loc[o, "Candidate ID"] for o in others)
                df.loc[keep, "Notes"] = (df.loc[keep, "Notes"] + "; " if df.loc[keep, "Notes"] else "") + note
            df = df.drop(index=drop).reset_index(drop=True)
            print("Merged. Removed %d duplicate row(s)." % len(removed_ids))
        else:
            print("Duplicates left as they are.")
    else:
        print("No duplicates found.")

    # stale "Possible duplicate of ..." notes
    def clean_note(n):
        n = re.sub(r"(?:;\s*)?Possible duplicate of CAN-\d+", "", n)
        n = re.sub(r"(?:;\s*)?Incomplete: [^;]*", "", n)
        return n.strip(" ;")
    df["Notes"] = df["Notes"].map(clean_note)

    # 3) incomplete
    review_idx = []
    for i, r in df.iterrows():
        miss = [c for c in REQUIRED if not str(r[c]).strip()]
        if miss:
            review_idx.append(i)
            df.loc[i, "Notes"] = (df.loc[i, "Notes"] + "; " if df.loc[i, "Notes"] else "") + \
                "Incomplete: " + ", ".join(miss)
    print("Incomplete records: %d" % len(review_idx))

    # write
    backup = OUT_DIR / ("CV_Master_backup_%s.xlsx" % datetime.now().strftime("%Y%m%d_%H%M%S"))
    try:
        shutil.copy2(OUT_FILE, backup)
        df = df.sort_values("Candidate ID", kind="stable").reset_index(drop=True)
        df.to_excel(OUT_FILE, index=False)
    except PermissionError:
        print("Cannot write the file. Close CV_Master.xlsx and run again.")
        return
    format_excel(OUT_FILE)
    if removed_rows:
        rem_file = OUT_DIR / "Removed_Duplicates.xlsx"
        rem = pd.DataFrame(removed_rows, columns=COLUMNS)
        if rem_file.exists():
            rem = pd.concat([pd.read_excel(rem_file, dtype=str).fillna(""), rem], ignore_index=True)
        rem.to_excel(rem_file, index=False)
        with open(LOG, "a", encoding="utf-8") as f:
            for name in removed_files:
                f.write(name + "\n")
    if review_idx:
        pd.DataFrame(df.loc[review_idx], columns=COLUMNS).to_excel(OUT_DIR / "Needs_Review.xlsx", index=False)
        format_excel(OUT_DIR / "Needs_Review.xlsx")
    print("\nDone. Backup of the old file: " + backup.name)
    if removed_rows:
        print("Removed rows were saved in output\\Removed_Duplicates.xlsx")
    if review_idx:
        print("Records that need a manual look: output\\Needs_Review.xlsx")


if __name__ == "__main__":
    main()
