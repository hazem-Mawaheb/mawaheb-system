# -*- coding: utf-8 -*-
"""
CV Matching - Exact 100-Point Weighting Breakdown
Title / Position:              15 points
Field / Domain Experience:     30 points  (20 field keywords + 10 years of experience)
Industry / Activity:           20 points
Education:                     10 points
Keywords:                      10 points
ERP & Software Systems:        10 points
Location:                       5 points
Total:                        100 points
"""

from pathlib import Path
import os
import re

import pandas as pd
from openpyxl import Workbook
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter

# ------------------------------------------------------------------ paths
BASE_DIR = Path(__file__).resolve().parent
OUTPUT_DIR = BASE_DIR / "output"
TEXT_DIR = OUTPUT_DIR / "cv_text"          # full CV text saved by main.py (START.bat)
MASTER = OUTPUT_DIR / "CV_Master.xlsx"
JOBS = BASE_DIR / "Jobs.xlsx"
RESULT = OUTPUT_DIR / "Matching_Results.xlsx"

OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

JOB_COLS = [
    "Job Title",
    "Field Keywords (comma separated)",
    "Industry / Activity (comma separated)",
    "General Keywords (comma separated)",
    "ERP & Systems (comma separated)",
    "Min Experience (Years)",
    "Max Experience (Years)",
    "Min Education (Diploma/Bachelor/Master/PhD)",
    "Location (optional)",
]

# ------------------------------------------------------------------ weights (total = 100)
W_TITLE = 15
W_FIELD = 30
W_FIELD_KW = 20     # part of W_FIELD: field keywords
W_FIELD_EXP = 10    # part of W_FIELD: years of experience
W_INDUS = 20
W_EDU = 10
W_KEYS = 10
W_ERP = 10
W_LOC = 5
assert W_TITLE + W_FIELD + W_INDUS + W_EDU + W_KEYS + W_ERP + W_LOC == 100
assert W_FIELD_KW + W_FIELD_EXP == W_FIELD

# CV_Master columns that are safe to search for keywords when the full CV text is not available
# (never Name, e-mail, passport, Emirates ID, date of birth, gender ...)
FALLBACK_COLS = ["Education", "Last Position", "Notes"]

# words that do not identify a job by themselves
GENERIC_TITLE_WORDS = {
    "manager", "senior", "junior", "assistant", "officer", "specialist", "executive",
    "director", "head", "lead", "supervisor", "coordinator", "chief", "associate",
    "مدير", "مسؤول", "رئيس", "مشرف", "منسق", "مساعد", "اخصائي", "أخصائي",
}


# ------------------------------------------------------------------ helpers
def norm(s):
    s = str(s or "").lower()
    s = re.sub("[أإآ]", "ا", s)
    s = s.replace("ة", "ه").replace("ى", "ي")
    s = re.sub(r"[^\w\s]", " ", s)
    return re.sub(r"\s+", " ", s).strip()


def has_term(text_norm, term):
    """True if `term` appears in the (already normalised) text.
    Latin terms must match whole words (so 'SAP' does not match 'sapient');
    Arabic terms use substring matching because of attached prefixes (و / ال / ب)."""
    t = norm(term)
    if not t:
        return False
    if re.search(r"[\u0600-\u06FF]", t):
        return t in text_norm
    return (" " + t + " ") in (" " + text_norm + " ")


def edu_level(text):
    t = " " + norm(text) + " "
    if re.search(r"phd|ph d|doctorate|doctoral|دكتوراه", t):
        return 4
    if re.search(r"master|mba|m sc|msc| ma |ماجستير", t):
        return 3
    if re.search(r"bachelor|b sc|bsc|bba| ba |beng|degree|بكالوريوس|جامعي", t):
        return 2
    if re.search(r"diploma|associate|دبلوم", t):
        return 1
    return 0


def to_num(v):
    try:
        return float(str(v).strip())
    except ValueError:
        return None


def fmt_num(n):
    return str(int(n)) if float(n).is_integer() else ("%.1f" % n)


def parse_list(val):
    return [k.strip() for k in re.split(r"[,;،\n]", str(val or "")) if k.strip()]


def sheet_name(name, used):
    """Valid, unique Excel sheet name (max 31 characters, no []:*?/\\)."""
    base = re.sub(r"[\[\]:*?/\\]", " ", str(name)).strip().strip("'") or "Sheet"
    base = re.sub(r"\s+", " ", base)[:31].strip() or "Sheet"
    cand, n = base, 2
    while cand.lower() in used:
        suffix = " (%d)" % n
        cand = base[:31 - len(suffix)] + suffix
        n += 1
    used.add(cand.lower())
    return cand


def candidate_text(c_dict):
    """Text used for keyword matching: the full CV text if main.py saved it,
    otherwise a few extracted fields. Returns (text, is_full_cv)."""
    src = str(c_dict.get("Source File", "")).strip()
    if src:
        f = TEXT_DIR / (src + ".txt")
        try:
            if f.exists():
                return f.read_text(encoding="utf-8"), True
        except OSError:
            pass
    return " ".join(str(c_dict.get(k, "")) for k in FALLBACK_COLS), False


# ------------------------------------------------------------------ Jobs.xlsx
def create_jobs_template():
    wb = Workbook()
    ws = wb.active
    ws.title = "Jobs"
    ws.append(JOB_COLS)
    ws.append([
        "HR Manager",
        "recruitment, manpower, payroll, توظيف, رواتب, تخطيط القوى العاملة",
        "Construction, Contracting, Manpower Leasing, المقاولات",
        "performance management, labor law, قانون العمل",
        "SAP, Oracle, Odoo, MenaPay",
        8,
        15,
        "Bachelor",
        "Abu Dhabi",
    ])
    for cell in ws[1]:
        cell.fill = PatternFill("solid", fgColor="1F4E78")
        cell.font = Font(name="Arial", bold=True, color="FFFFFF")
        cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
    for cell in ws[2]:
        cell.font = Font(name="Arial", size=10, color="0000FF")
        cell.alignment = Alignment(vertical="top", wrap_text=True)
    for i, w in enumerate([22, 38, 32, 36, 26, 16, 16, 24, 18], 1):
        ws.column_dimensions[get_column_letter(i)].width = w
    ws.row_dimensions[1].height = 45
    ws.freeze_panes = "B2"

    info = wb.create_sheet("Instructions")
    for line in [
        "Row 2 is an EXAMPLE (blue text). Replace it with your real job; one job per row.",
        "Scoring (100 points): Title 15 | Field/Domain experience 30 | Industry 20 | Education 10 | Keywords 10 | ERP 10 | Location 5.",
        "Job Title (15): compared with the candidate's Last Position.",
        "Field Keywords (20 of the 30 points): skills / domain words that must appear in the CV. Years of experience give the other 10.",
        "Industry / Activity (20): sectors the candidate should have worked in.",
        "General Keywords (10): any other words you want to find in the CV.",
        "ERP & Systems (10): software names, e.g. SAP, Oracle, Odoo.",
        "Min / Max Experience: in years. Below Min the points are reduced; above Max only a note is added.",
        "Min Education: Diploma, Bachelor, Master or PhD.  Location: city, e.g. Abu Dhabi.",
        "Separate keywords with commas (English and Arabic are both fine). Leave a cell empty to give that criterion full points.",
        "Then run MATCH.bat.",
        "",
        "الصف الثاني مثال فقط (بالخط الأزرق). استبدله بوظيفتك، وأضف وظيفة في كل صف.",
        "التوزيع: المسمى 15 | خبرة المجال 30 | القطاع 20 | المؤهل 10 | الكلمات المفتاحية 10 | أنظمة ERP 10 | الموقع 5.",
        "اترك أي خلية فارغة ليأخذ ذلك المعيار الدرجة الكاملة.",
    ]:
        info.append([line])
    info.column_dimensions["A"].width = 130
    wb.save(JOBS)


def read_jobs():
    df = pd.read_excel(JOBS, sheet_name=0, dtype=str).fillna("")
    df.columns = [str(c).strip() for c in df.columns]
    missing = [c for c in JOB_COLS if c not in df.columns]
    if missing:
        raise ValueError(
            "Jobs.xlsx بصيغة قديمة (أعمدة ناقصة). احذف الملف وشغّل MATCH.bat ليُنشأ القالب الجديد.\n"
            "Jobs.xlsx is in the old format. Delete it and run MATCH.bat to create the new template.\n"
            "Missing: " + " | ".join(missing))
    jobs = []
    for _, r in df.iterrows():
        title = str(r[JOB_COLS[0]]).strip()
        if not title:
            continue
        edu_txt = str(r[JOB_COLS[7]]).strip()
        jobs.append({
            "title": title,
            "field_kws": parse_list(r[JOB_COLS[1]]),
            "industry_kws": parse_list(r[JOB_COLS[2]]),
            "general_kws": parse_list(r[JOB_COLS[3]]),
            "erp_kws": parse_list(r[JOB_COLS[4]]),
            "min_exp": to_num(r[JOB_COLS[5]]),
            "max_exp": to_num(r[JOB_COLS[6]]),
            "min_edu": edu_level(edu_txt) if edu_txt else 0,
            "location": str(r[JOB_COLS[8]]).strip(),
        })
    return jobs


# ------------------------------------------------------------------ scoring
def keyword_points(kws, text_norm, weight, boost):
    """(points, hits). `boost` > 1 means the full mark is reached before all keywords are found."""
    hits = [k for k in kws if has_term(text_norm, k)]
    pts = round(weight * min(len(hits) / len(kws) * boost, 1.0))
    return pts, hits


def score_candidate(job, c_dict, text=None):
    """Returns (total score, parts, why). parts = {name: (points, max_points)}."""
    parts, why = {}, []
    if text is None:
        text, full = candidate_text(c_dict)
    text_norm = norm(text)

    # 1. Title / Position (15)
    pos = norm(c_dict.get("Last Position", ""))
    job_t = norm(job["title"])
    if not pos:
        parts["Title"] = (0, W_TITLE)
        why.append("المسمى غير محدد")
    elif (" " + job_t + " ") in (" " + pos + " "):
        parts["Title"] = (W_TITLE, W_TITLE)                      # e.g. "Senior HR Manager" for "HR Manager"
    else:
        common = set(pos.split()) & set(job_t.split())
        specific = common - GENERIC_TITLE_WORDS
        if specific:
            parts["Title"] = (10, W_TITLE)
            why.append("مسمى قريب أو مستوى مختلف")
        elif common:
            parts["Title"] = (3, W_TITLE)
            why.append("المسمى يشترك في المستوى فقط وليس في التخصص")
        else:
            parts["Title"] = (0, W_TITLE)
            why.append("المسمى الوظيفي غير مطابق")

    # 2. Field / Domain Experience (30) = field keywords (20) + years (10)
    if job["field_kws"]:
        kw_pts, hits = keyword_points(job["field_kws"], text_norm, W_FIELD_KW, 1.5)
        if not hits:
            why.append("لم تظهر كلمات المجال المطلوبة")
    else:
        kw_pts = W_FIELD_KW

    y = to_num(c_dict.get("Experience (Years)", ""))
    if job["min_exp"] is None:
        exp_pts = W_FIELD_EXP
    elif y is None:
        exp_pts = 0
        why.append("سنوات الخبرة غير محددة")
    elif y >= job["min_exp"]:
        exp_pts = W_FIELD_EXP
    else:
        exp_pts = round(W_FIELD_EXP * (y / job["min_exp"])) if job["min_exp"] > 0 else W_FIELD_EXP
        why.append("الخبرة أقل بـ %s سنوات" % fmt_num(job["min_exp"] - y))
    if job["max_exp"] is not None and y is not None and y > job["max_exp"]:
        why.append("الخبرة أعلى من الحد الأقصى (%s سنة)" % fmt_num(job["max_exp"]))
    parts["Field Exp"] = (min(kw_pts + exp_pts, W_FIELD), W_FIELD)

    # 3. Industry / Activity (20)
    if job["industry_kws"]:
        pts, hits = keyword_points(job["industry_kws"], text_norm, W_INDUS, 2.0)
        parts["Industry"] = (pts, W_INDUS)
        if not hits:
            why.append("لم تذكر خبرة سابقة في نفس القطاع")
    else:
        parts["Industry"] = (W_INDUS, W_INDUS)

    # 4. Education (10)
    if job["min_edu"]:
        lv = edu_level(c_dict.get("Education", ""))
        if lv == 0:
            parts["Education"] = (0, W_EDU)
            why.append("المؤهل غير محدد")
        elif lv >= job["min_edu"]:
            parts["Education"] = (W_EDU, W_EDU)
        elif lv == job["min_edu"] - 1:
            parts["Education"] = (5, W_EDU)
            why.append("المؤهل أقل بمستوى واحد")
        else:
            parts["Education"] = (0, W_EDU)
            why.append("المؤهل أقل من المطلوب")
    else:
        parts["Education"] = (W_EDU, W_EDU)

    # 5. General keywords (10)
    if job["general_kws"]:
        pts, _ = keyword_points(job["general_kws"], text_norm, W_KEYS, 1.3)
        parts["Keywords"] = (pts, W_KEYS)
    else:
        parts["Keywords"] = (W_KEYS, W_KEYS)

    # 6. ERP & software systems (10)
    if job["erp_kws"]:
        pts, hits = keyword_points(job["erp_kws"], text_norm, W_ERP, 1.5)
        parts["ERP"] = (pts, W_ERP)
        if not hits:
            why.append("لم تذكر معرفة بأنظمة ERP المطلوبة")
    else:
        parts["ERP"] = (W_ERP, W_ERP)

    # 7. Location (5)
    if job["location"]:
        loc = norm(c_dict.get("Current Location", ""))
        want = norm(job["location"])
        if not loc:
            parts["Location"] = (0, W_LOC)
            why.append("موقع المرشح غير محدد")
        elif want in loc or loc in want:
            parts["Location"] = (W_LOC, W_LOC)
        else:
            parts["Location"] = (0, W_LOC)
            why.append("الموقع/المدينة مختلف")
    else:
        parts["Location"] = (W_LOC, W_LOC)

    score = sum(v[0] for v in parts.values())
    return score, parts, why


def rating(score):
    if score >= 80:
        return "Strong"
    if score >= 65:
        return "Good"
    if score >= 50:
        return "Possible"
    return "Weak"


# ------------------------------------------------------------------ output
OUT_COLS = [
    "Rank", "Candidate ID", "Name", "Total Score (100)", "Rating",
    "Title (15)", "Field Exp (30)", "Industry (20)", "Education (10)", "Keywords (10)",
    "ERP (10)", "Location (5)",
    "Last Position", "Experience (Years)", "Education", "Nationality", "Current Location",
    "Email", "Mobile", "Notes / Why",
]
OUT_WIDTHS = [7, 13, 26, 11, 11, 9, 11, 11, 11, 11, 9, 10, 30, 12, 34, 14, 20, 30, 18, 60]
FILLS = {"Strong": "C6EFCE", "Good": "E2EFDA", "Possible": "FFEB9C", "Weak": "F8CBAD"}
PART_KEYS = ["Title", "Field Exp", "Industry", "Education", "Keywords", "ERP", "Location"]


def main():
    if not JOBS.exists():
        create_jobs_template()
        print("تم إنشاء ملف Jobs.xlsx (توزيع 100 نقطة). عبّئه ثم أعد تشغيل MATCH.bat.")
        print("Jobs.xlsx was created. Fill it in, save, then run MATCH.bat again.")
        try:
            os.startfile(JOBS)
        except Exception:
            pass
        return

    if not MASTER.exists():
        print("لم يتم العثور على output\\CV_Master.xlsx. شغّل START.bat أولاً.")
        print("output\\CV_Master.xlsx not found. Run START.bat first.")
        return

    try:
        jobs = read_jobs()
        cand = pd.read_excel(MASTER, dtype=str).fillna("")
    except PermissionError:
        print("يرجى إغلاق ملفات الإكسل المفتوحة (Jobs أو CV_Master) ثم إعادة المحاولة.")
        return
    except ValueError as exc:
        print(exc)
        return

    if not jobs:
        print("لا توجد وظائف في Jobs.xlsx. / No jobs found in Jobs.xlsx.")
        return
    if cand.empty:
        print("CV_Master.xlsx فارغ. / CV_Master.xlsx has no candidates.")
        return

    wb = Workbook()
    summary = wb.active
    summary.title = "Summary"
    summary.append(["Job Title", "Candidates", "Strong (80+)", "Good (65-79)", "Possible (50-64)", "Weak (<50)", "Best Score"])
    used = {"summary"}
    no_text = 0

    for job in jobs:
        rows = []
        for _, c in cand.iterrows():
            c_dict = c.to_dict()
            text, full = candidate_text(c_dict)
            score, parts, why = score_candidate(job, c_dict, text)
            if not full:
                no_text += 1
                why.append("لا يوجد نص كامل للسيرة - المطابقة على الحقول المستخرجة فقط")
            notes = "; ".join(x for x in [c_dict.get("Notes", ""), "; ".join(why)] if x)
            y = to_num(c_dict.get("Experience (Years)", ""))
            rows.append([
                0, c_dict.get("Candidate ID", ""), c_dict.get("Name", ""), score, rating(score),
                *[parts[k][0] for k in PART_KEYS],
                c_dict.get("Last Position", ""), c_dict.get("Experience (Years)", ""),
                c_dict.get("Education", ""), c_dict.get("Nationality", ""),
                c_dict.get("Current Location", ""), c_dict.get("Email", ""), c_dict.get("Mobile", ""),
                notes, y or 0,
            ])
        rows.sort(key=lambda r: (-r[3], -r[-1], str(r[1])))
        for i, r in enumerate(rows, 1):
            r[0] = i

        ws = wb.create_sheet(sheet_name(job["title"], used))
        ws.append(OUT_COLS)
        for r in rows:
            ws.append(r[:-1])
        for cell in ws[1]:
            cell.fill = PatternFill("solid", fgColor="1F4E78")
            cell.font = Font(name="Arial", bold=True, color="FFFFFF")
            cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
        for row in ws.iter_rows(min_row=2):
            for cell in row:
                cell.font = Font(name="Arial", size=10)
                cell.alignment = Alignment(vertical="top", wrap_text=True)
            fill = PatternFill("solid", fgColor=FILLS.get(row[4].value, "FFFFFF"))
            row[3].fill = fill
            row[4].fill = fill
            row[3].font = Font(name="Arial", size=10, bold=True)
        for i, w in enumerate(OUT_WIDTHS, 1):
            ws.column_dimensions[get_column_letter(i)].width = w
        ws.row_dimensions[1].height = 32
        ws.freeze_panes = "D2"
        ws.auto_filter.ref = ws.dimensions

        counts = {k: sum(1 for r in rows if r[4] == k) for k in FILLS}
        summary.append([job["title"], len(rows), counts["Strong"], counts["Good"], counts["Possible"],
                        counts["Weak"], rows[0][3] if rows else 0])
        print("  %-30s %d candidate(s)  | Strong %d  Good %d  Possible %d  Weak %d" %
              (job["title"], len(rows), counts["Strong"], counts["Good"], counts["Possible"], counts["Weak"]))

    for cell in summary[1]:
        cell.fill = PatternFill("solid", fgColor="1F4E78")
        cell.font = Font(name="Arial", bold=True, color="FFFFFF")
        cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
    for row in summary.iter_rows(min_row=2):
        for cell in row:
            cell.font = Font(name="Arial", size=10)
    for i, w in enumerate([30, 12, 14, 14, 16, 12, 12], 1):
        summary.column_dimensions[get_column_letter(i)].width = w
    summary.row_dimensions[1].height = 32

    if no_text:
        print("\nتنبيه: بعض السير بلا نص كامل؛ شغّل START.bat مرة واحدة لحفظ النصوص ثم أعد المطابقة.")
        print("Note: some CVs have no saved text. Run START.bat once to save it, then run MATCH.bat again.")
    try:
        wb.save(RESULT)
    except PermissionError:
        print("أغلق ملف Matching_Results.xlsx ثم أعد التشغيل. / Close Matching_Results.xlsx and run again.")
        return
    print("\nDone. File saved to:\n  ", RESULT)
    try:
        os.startfile(RESULT)
    except Exception:
        pass


if __name__ == "__main__":
    main()
