# -*- coding: utf-8 -*-
"""
Shortlists: reads rules from Filters.xlsx (one row = one shortlist) and writes
output/Shortlist.xlsx (one sheet per rule). Shortlists never include passport, Emirates ID,
date of birth or gender, so they are safe to forward.
"""
from pathlib import Path
import os
import re

import pandas as pd
from openpyxl import Workbook, load_workbook
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter

import match
from match import edu_level, norm, rating, read_jobs, score_candidate, sheet_name, to_num

BASE_DIR = Path(__file__).resolve().parent
MASTER = match.MASTER
FILTERS = BASE_DIR / "Filters.xlsx"
RESULT = BASE_DIR / "output" / "Shortlist.xlsx"

F_COLS = ["Shortlist Name", "Job Title (from Jobs.xlsx, optional)", "Top N", "Min Score (0-100)",
          "Min Experience (Years)", "Max Experience (Years)",
          "Min Education (Diploma/Bachelor/Master/PhD)", "Nationality (comma separated, optional)",
          "Location contains (optional)"]
OUT_COLS = ["Rank", "Candidate ID", "Name", "Score", "Rating", "Nationality", "Education", "Last Position",
            "Experience (Years)", "Current Location", "Email", "Mobile", "WhatsApp", "Notice Period", "Notes"]
WIDTHS = [7, 13, 26, 8, 10, 16, 34, 30, 12, 20, 30, 18, 18, 14, 34]


def create_template():
    wb = Workbook()
    ws = wb.active
    ws.title = "Filters"
    ws.append(F_COLS)
    ws.append(["IT Manager - Top 10", "IT Manager", 10, 60, 5, "", "Bachelor", "", "Abu Dhabi"])
    for c in ws[1]:
        c.fill = PatternFill("solid", fgColor="1F4E78")
        c.font = Font(name="Arial", bold=True, color="FFFFFF")
        c.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
    for c in ws[2]:
        c.font = Font(name="Arial", size=10, color="0000FF")
    for i, w in enumerate([28, 30, 9, 14, 16, 16, 26, 30, 24], 1):
        ws.column_dimensions[get_column_letter(i)].width = w
    ws.row_dimensions[1].height = 48
    info = wb.create_sheet("Instructions")
    for line in [
        "Row 2 is an EXAMPLE (blue text). Replace it with your own rule; one shortlist per row.",
        "Shortlist Name: becomes the sheet name.",
        "Job Title: must match a job in Jobs.xlsx. It ranks candidates by match score. Leave empty to rank by experience.",
        "Top N: how many candidates to keep. Empty = all.",
        "Min Score: lowest match score (needs a Job Title).",
        "Nationality: write as it appears in CV_Master, e.g. Emirati, Egyptian. Separate with commas.",
        "Location contains: e.g. Abu Dhabi.",
        "Leave a cell empty to ignore that condition. Then run SHORTLIST.bat.",
        "",
        "الصف الثاني مثال (بالخط الأزرق). استبدله بشروطك، كل صف = قائمة مختصرة.",
        "اكتب الجنسية كما تظهر في الجدول بالإنجليزية، وافصل بين الجنسيات بفواصل.",
        "اترك أي خلية فارغة لتجاهل ذلك الشرط.",
    ]:
        info.append([line])
    info.column_dimensions["A"].width = 110
    wb.save(FILTERS)


def main():
    if not FILTERS.exists():
        create_template()
        print("Filters.xlsx was created. Fill in your rule(s), save, close it, then run SHORTLIST.bat again.")
        try:
            os.startfile(FILTERS)
        except Exception:
            pass
        return
    if not MASTER.exists():
        print("output\\CV_Master.xlsx not found. Run START.bat first.")
        return
    try:
        rules = pd.read_excel(FILTERS, sheet_name=0, dtype=str).fillna("")
        cand = pd.read_excel(MASTER, dtype=str).fillna("")
        jobs = {j["title"].lower(): j for j in read_jobs()} if match.JOBS.exists() else {}
    except PermissionError:
        print("Please close Filters.xlsx / Jobs.xlsx / CV_Master.xlsx, then run again.")
        return
    rules.columns = [str(c).strip() for c in rules.columns]
    wb = Workbook()
    wb.remove(wb.active)
    used = set()
    made = 0
    for _, rule in rules.iterrows():
        name = rule.get(F_COLS[0], "").strip()
        if not name:
            continue
        job_title = rule.get(F_COLS[1], "").strip()
        job = jobs.get(job_title.lower()) if job_title else None
        if job_title and not job:
            print("  ! Job '%s' not found in Jobs.xlsx - '%s' will be ranked by experience." % (job_title, name))
        top = to_num(rule.get(F_COLS[2], ""))
        min_score = to_num(rule.get(F_COLS[3], ""))
        min_exp, max_exp = to_num(rule.get(F_COLS[4], "")), to_num(rule.get(F_COLS[5], ""))
        edu_txt = rule.get(F_COLS[6], "").strip()
        min_edu = edu_level(edu_txt) if edu_txt else 0
        nats = [norm(n) for n in re.split(r"[,;،]", rule.get(F_COLS[7], "")) if n.strip()]
        loc = norm(rule.get(F_COLS[8], ""))

        rows = []
        for _, c in cand.iterrows():
            c = c.to_dict()
            y = to_num(c.get("Experience (Years)", ""))
            if min_exp is not None and (y is None or y < min_exp):
                continue
            if max_exp is not None and (y is None or y > max_exp):
                continue
            if min_edu and edu_level(c.get("Education", "")) < min_edu:
                continue
            if nats and not any(n == norm(c.get("Nationality", "")) or n in norm(c.get("Nationality", "")) and n
                                for n in nats):
                continue
            if loc and loc not in norm(c.get("Current Location", "")):
                continue
            if job:
                score, _, why = score_candidate(job, c)
                if min_score is not None and score < min_score:
                    continue
                sc, rt = score, rating(score)
                note = "; ".join(x for x in [c.get("Notes", ""), "; ".join(why)] if x)
            else:
                sc, rt, note = "", "", c.get("Notes", "")
            rows.append([0, c["Candidate ID"], c["Name"], sc, rt, c["Nationality"], c["Education"],
                         c["Last Position"], c["Experience (Years)"], c["Current Location"],
                         c["Email"], c["Mobile"], c["WhatsApp"], c["Notice Period"], note, y or 0])
        rows.sort(key=lambda r: (-(r[3] if r[3] != "" else 0), -r[-1]))
        if top:
            rows = rows[:int(top)]
        for i, r in enumerate(rows, 1):
            r[0] = i
        ws = wb.create_sheet(sheet_name(name, used))
        ws.append(OUT_COLS)
        for r in rows:
            ws.append(r[:-1])
        for cell in ws[1]:
            cell.fill = PatternFill("solid", fgColor="1F4E78")
            cell.font = Font(name="Arial", bold=True, color="FFFFFF")
            cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
        for row in ws.iter_rows(min_row=2):
            for cell in row:
                cell.font = Font(name="Arial", size=10)
                cell.alignment = Alignment(vertical="top", wrap_text=True)
        for i, w in enumerate(WIDTHS, 1):
            ws.column_dimensions[get_column_letter(i)].width = w
        ws.row_dimensions[1].height = 30
        ws.freeze_panes = "D2"
        ws.auto_filter.ref = ws.dimensions
        print("  %-32s %d candidate(s)" % (name, len(rows)))
        made += 1
    if not made:
        print("No rule found in Filters.xlsx. Fill row 2 onwards, save, and run again.")
        return
    try:
        wb.save(RESULT)
    except PermissionError:
        print("Close Shortlist.xlsx, then run SHORTLIST.bat again.")
        return
    print("\nDone. File saved to:\n  ", RESULT)
    try:
        os.startfile(RESULT)
    except Exception:
        pass


if __name__ == "__main__":
    main()
