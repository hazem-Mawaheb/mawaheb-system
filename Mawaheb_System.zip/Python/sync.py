# -*- coding: utf-8 -*-
"""
Sends the CVs read from the "cvs" folder (output/CV_Master.xlsx + output/cv_text) to the unified Google Sheet.
Setup once: put the Web App URL and the TOKEN in config.json (the TOKEN is shown by Mawaheb > Setup in the sheet).
Run:  SYNC.bat            -> sends only CVs not sent before
      SYNC.bat --all      -> sends everything again (the sheet merges by e-mail / mobile, so no duplicates)
"""
from pathlib import Path
import json
import sys
import urllib.request

import pandas as pd

BASE_DIR = Path(__file__).resolve().parent
OUT_DIR = BASE_DIR / "output"
OUT_FILE = OUT_DIR / "CV_Master.xlsx"
TEXT_DIR = OUT_DIR / "cv_text"
CONFIG = BASE_DIR / "config.json"
SYNCED = OUT_DIR / "synced_files.txt"
CHUNK = 8
MAX_TEXT = 45000


def load_config():
    if not CONFIG.exists():
        raise RuntimeError("config.json not found")
    cfg = json.loads(CONFIG.read_text(encoding="utf-8"))
    if "PASTE" in cfg.get("WEB_APP_URL", "") or "PASTE" in cfg.get("TOKEN", "") or not cfg.get("TOKEN"):
        raise RuntimeError("fill WEB_APP_URL and TOKEN in config.json first")
    return cfg


def post(cfg, payload):
    body = json.dumps(dict(payload, token=cfg["TOKEN"])).encode("utf-8")
    req = urllib.request.Request(cfg["WEB_APP_URL"], data=body, headers={"Content-Type": "text/plain;charset=utf-8"})
    with urllib.request.urlopen(req, timeout=180) as r:
        return json.loads(r.read().decode("utf-8"))


def push_new(everything=False):
    cfg = load_config()
    if not OUT_FILE.exists():
        print("output\\CV_Master.xlsx not found. Run START.bat first.")
        return
    df = pd.read_excel(OUT_FILE, dtype=str).fillna("")
    done = set()
    if SYNCED.exists() and not everything:
        done = {l.strip() for l in SYNCED.read_text(encoding="utf-8").splitlines() if l.strip()}
    rows = [r for _, r in df.iterrows() if r.get("Source File", "") and r["Source File"] not in done]
    if not rows:
        print("Google Sheet: nothing new to send.")
        return
    print("Google Sheet: sending %d CV(s)..." % len(rows))
    sent, added, merged = [], 0, 0
    for i in range(0, len(rows), CHUNK):
        part = rows[i:i + CHUNK]
        records, texts = [], {}
        for r in part:
            rec = {k: v for k, v in r.to_dict().items() if k != "Candidate ID" and str(v).strip()}
            records.append(rec)
            tf = TEXT_DIR / (r["Source File"] + ".txt")
            if tf.exists():
                texts[r["Source File"]] = tf.read_text(encoding="utf-8")[:MAX_TEXT]
        try:
            res = post(cfg, {"action": "upsert", "source": "Folder", "records": records, "texts": texts})
        except Exception as exc:
            print("  ! failed (%s). Run SYNC.bat again later." % exc)
            break
        if not res.get("ok"):
            print("  ! the sheet refused the request:", res.get("error"))
            break
        for x in res.get("results", []):
            sent.append(x["file"])
            added += x["status"] == "added"
            merged += x["status"] == "merged"
    if sent:
        with open(SYNCED, "a", encoding="utf-8") as f:
            for name in sent:
                f.write(name + "\n")
    print("Google Sheet: %d new, %d merged with existing candidates." % (added, merged))


if __name__ == "__main__":
    try:
        push_new("--all" in sys.argv)
    except Exception as exc:
        print("Sync error:", exc)
