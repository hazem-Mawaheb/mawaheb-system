@echo off
chcp 65001 >nul
title CV Reader - Simple
cd /d "%~dp0"

echo ============================================
echo   CV Reader - قارئ السير الذاتية
echo ============================================
echo.

REM --- Find Python ---
set PY=
where py >nul 2>nul && set PY=py
if "%PY%"=="" (
    where python >nul 2>nul && set PY=python
)
if "%PY%"=="" (
    echo [ERROR] Python is not installed.
    echo Install it from https://www.python.org/downloads/
    echo IMPORTANT: tick "Add Python to PATH" during installation.
    echo.
    pause
    exit /b 1
)

REM --- Environment ---
if not exist ".venv\Scripts\python.exe" (
    echo [1/3] First run: preparing the environment. Please wait...
    %PY% -m venv .venv
    if errorlevel 1 (
        echo [ERROR] Could not create the environment.
        pause
        exit /b 1
    )
    ".venv\Scripts\python.exe" -m pip install --upgrade pip
)

REM --- Libraries (installed once; re-installed when requirements change) ---
if not exist ".venv\deps_v3.ok" (
    echo [2/3] Installing libraries including OCR. Please wait...
    ".venv\Scripts\python.exe" -m pip install -r requirements.txt
    if errorlevel 1 (
        echo [ERROR] Could not install the libraries. Check your internet connection.
        pause
        exit /b 1
    )
    echo ok> ".venv\deps_v3.ok"
    echo.
)

if not exist "cvs" mkdir cvs
if not exist "output" mkdir output

echo [3/3] Reading CVs from the "cvs" folder...
echo.
".venv\Scripts\python.exe" main.py
echo.
pause
