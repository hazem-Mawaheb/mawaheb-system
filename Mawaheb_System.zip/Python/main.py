# -*- coding: utf-8 -*-
"""
CV Reader - Simple version (v2)
Reads PDF and Word (DOCX) CVs, Arabic + English, and appends them to one Excel file.
Fields that the CV does not contain are left blank (the program never guesses).
"""
from pathlib import Path
from datetime import datetime, timedelta
import os
import re
import shutil

import pandas as pd
import pdfplumber
from docx import Document
from openpyxl import load_workbook
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter

try:
    import dateparser
except ImportError:
    dateparser = None

BASE_DIR = Path(__file__).resolve().parent
CV_DIR = BASE_DIR / "cvs"
OUT_DIR = BASE_DIR / "output"
OUT_FILE = OUT_DIR / "CV_Master.xlsx"
TEXT_DIR = OUT_DIR / "cv_text"   # full CV text, used by MATCH.bat for keyword matching
IMAGE_EXT = {".jpg", ".jpeg", ".png"}
SUPPORTED = {".pdf", ".docx"} | IMAGE_EXT
OCR_MAX_PAGES = 6
RETRY_PREFIXES = ("No readable text", "Scanned file")

COLUMNS = [
    "Candidate ID", "Name", "Nationality", "Date of Birth", "Gender",
    "Education", "Last Position", "Experience (Years)",
    "Email", "Mobile", "WhatsApp", "Current Location",
    "Passport No.", "Passport Expiry", "Driving License Type", "License Expiry",
    "Residency / Visa Type", "Emirates ID", "Notice Period",
    "Source File", "Notes",
]
WIDTHS = [14, 26, 16, 14, 10, 38, 30, 12, 30, 18, 18, 24, 16, 14, 22, 14, 24, 22, 16, 34, 36]
EXPIRY_COLS = ["Passport Expiry", "License Expiry"]

# ---------------------------------------------------------------- reading
def read_pdf(path):
    parts = []
    with pdfplumber.open(path) as pdf:
        for page in pdf.pages:
            t = page.extract_text(x_tolerance=2, y_tolerance=3)
            if t:
                parts.append(t)
    return "\n".join(parts)


def read_docx(path):
    doc = Document(path)
    parts = [p.text.strip() for p in doc.paragraphs if p.text.strip()]
    for table in doc.tables:
        for row in table.rows:
            cells = [c.text.strip() for c in row.cells]
            if any(cells):
                parts.append(" | ".join(cells))
    return "\n".join(parts)


def clean(text):
    text = text.replace("\u00a0", " ")
    text = text.translate(str.maketrans("٠١٢٣٤٥٦٧٨٩۰۱۲۳۴۵۶۷۸۹", "01234567890123456789"))
    text = re.sub(r"[ \t]+", " ", text)
    text = re.sub(r"\n{3,}", "\n\n", text)
    return text.strip()

# ---------------------------------------------------------------- helpers
_CUT1 = re.compile(r"\s{2,}")
_CUT2 = re.compile(r"\s+(?:Date of Birth|(?:[A-Za-z/]+ )?(?:Expiry|Expires|Number|No\.?|Date|Birth|Status|Type|Nationality|Gender|Sex|Email|Mobile|Phone|Tel|WhatsApp|Location|Address|Education|Position|Name|Visa|ID|Notice|Availability|Experience|Residency|DOB))\s*:\s", re.IGNORECASE)


def labeled(text, labels, nl=False, loose=False):
    """Value that follows one of the labels (same line, next line, or just a space)."""
    alt = "|".join(re.escape(x) for x in sorted(labels, key=len, reverse=True))
    start = r"(?<![A-Za-z])(?:%s)" % alt
    m = re.search(start + r"[ \t]*[:：\-–|][ \t]*([^\n|]+)", text, re.IGNORECASE)
    if not (m and m.group(1).strip(" :-|،")) and nl:
        m = re.search(start + r"[ \t]*[:：]?[ \t]*\n[ \t]*([^\n|]+)", text, re.IGNORECASE)
    if not (m and m.group(1).strip(" :-|،")) and loose:
        m = re.search(start + r"[ \t]+([^\n|]+)", text, re.IGNORECASE)
    if not m:
        return ""
    v = m.group(1).strip(" :-|،")
    v = _CUT1.split(v)[0]
    return _CUT2.split(v)[0].strip(" :-|،")


_DATE_PATTERNS = [
    r"\d{4}-\d{1,2}-\d{1,2}",
    r"\d{1,2}[/.\-]\d{1,2}[/.\-]\d{2,4}",
    r"\d{1,2}(?:st|nd|rd|th)?\s+[A-Za-z]{3,9}\.?,?\s+\d{4}",
    r"[A-Za-z]{3,9}\.?\s+\d{1,2}(?:st|nd|rd|th)?,?\s+\d{4}",
]
_DATE_FORMATS = ["%Y-%m-%d", "%d/%m/%Y", "%d-%m-%Y", "%d.%m.%Y", "%d/%m/%y", "%d-%m-%y",
                 "%d %b %Y", "%d %B %Y", "%b %d %Y", "%B %d %Y"]


def parse_date(value):
    """Return YYYY-MM-DD if a date is found, otherwise the original text."""
    if not value:
        return ""
    for pat in _DATE_PATTERNS:
        m = re.search(pat, value)
        if not m:
            continue
        s = re.sub(r"(?<=\d)(st|nd|rd|th)", "", m.group(0)).replace(",", " ").replace(".", " ") \
            if re.search(r"[A-Za-z]", m.group(0)) else m.group(0)
        s = re.sub(r"\s+", " ", s).strip()
        for f in _DATE_FORMATS:
            try:
                return datetime.strptime(s, f).strftime("%Y-%m-%d")
            except ValueError:
                pass
        if dateparser:
            d = dateparser.parse(s, settings={"DATE_ORDER": "DMY"})
            if d:
                return d.strftime("%Y-%m-%d")
    return value[:30]

# ---------------------------------------------------------------- OCR
TESS_PATHS = [
    r"C:\Program Files\Tesseract-OCR\tesseract.exe",
    r"C:\Program Files (x86)\Tesseract-OCR\tesseract.exe",
    os.path.join(os.environ.get("LOCALAPPDATA", ""), "Programs", "Tesseract-OCR", "tesseract.exe"),
]
_ocr_cache = {}


def ocr_engine():
    """Return (pytesseract_module, lang, warning) or (None, None, reason)."""
    if "v" in _ocr_cache:
        return _ocr_cache["v"]
    try:
        import pytesseract
    except ImportError:
        res = (None, None, "OCR library missing (run START.bat again with internet)")
        _ocr_cache["v"] = res
        return res
    cmd = shutil.which("tesseract") or next((p for p in TESS_PATHS if os.path.exists(p)), None)
    if not cmd:
        res = (None, None, "Tesseract is not installed")
        _ocr_cache["v"] = res
        return res
    pytesseract.pytesseract.tesseract_cmd = cmd
    try:
        langs = pytesseract.get_languages(config="")
    except Exception:
        langs = ["eng"]
    if "ara" in langs and "eng" in langs:
        res = (pytesseract, "ara+eng", "")
    elif "eng" in langs:
        res = (pytesseract, "eng", "Arabic OCR data missing - English only")
    else:
        res = (pytesseract, langs[0], "English OCR data missing")
    _ocr_cache["v"] = res
    return res


def ocr_file(path):
    """OCR a scanned PDF or an image. Returns (text, warning) or (None, reason)."""
    tess, lang, warn = ocr_engine()
    if tess is None:
        return None, warn
    from PIL import Image
    images = []
    if path.suffix.lower() == ".pdf":
        import pypdfium2 as pdfium
        pdf = pdfium.PdfDocument(str(path))
        for i in range(min(len(pdf), OCR_MAX_PAGES)):
            images.append(pdf[i].render(scale=300 / 72).to_pil())
    else:
        images.append(Image.open(path))
    parts = []
    for img in images:
        parts.append(tess.image_to_string(img.convert("L"), lang=lang))
    return "\n".join(parts), warn


# ---------------------------------------------------------------- fields
PHONE_RE = r"(?:\+|00)?\d[\d\s\-()]{7,18}\d"
EID_RE = r"784[\s\-]?\d{4}[\s\-]?\d{7}[\s\-]?\d"
WA_RE = r"(?:whats\s*app|واتس\s*اب|واتساب)[ \t]*(?:no\.?|number|رقم)?[ \t]*[:\-–]?[ \t]*(" + PHONE_RE + ")"


def get_email(text):
    m = re.search(r"[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}", text)
    return m.group(0) if m else ""


def get_whatsapp(text):
    m = re.search(WA_RE, text, re.IGNORECASE)
    return re.sub(r"\s+", " ", m.group(1)).strip() if m else ""


def get_emirates_id(text):
    m = re.search(EID_RE, text)
    if not m:
        return ""
    d = re.sub(r"\D", "", m.group(0))
    return "%s-%s-%s-%s" % (d[:3], d[3:7], d[7:14], d[14])


def get_phone(text):
    t = re.sub(WA_RE, " ", text, flags=re.IGNORECASE)
    t = re.sub(EID_RE, " ", t)
    for m in re.finditer(PHONE_RE, t):
        v = re.sub(r"\s+", " ", m.group(0)).strip()
        digits = re.sub(r"\D", "", v)
        if re.search(r"(19|20)\d{2}\s*[-–]\s*(19|20)\d{2}", v):
            continue
        if 9 <= len(digits) <= 15:
            return v
    return ""


def get_dob(text):
    v = labeled(text, ["Date of Birth", "Birth Date", "Birthdate", "Date Of Birth", "D.O.B", "DOB",
                       "تاريخ الميلاد", "تاريخ الولادة", "الميلاد"], nl=True, loose=True)
    return parse_date(v)


AR_NAT = {
    "مصري": "Egyptian", "مصرية": "Egyptian", "سوري": "Syrian", "سورية": "Syrian",
    "أردني": "Jordanian", "اردني": "Jordanian", "أردنية": "Jordanian",
    "لبناني": "Lebanese", "لبنانية": "Lebanese", "فلسطيني": "Palestinian",
    "فلسطينية": "Palestinian", "عراقي": "Iraqi", "عراقية": "Iraqi",
    "سوداني": "Sudanese", "سودانية": "Sudanese", "يمني": "Yemeni", "يمنية": "Yemeni",
    "هندي": "Indian", "هندية": "Indian", "باكستاني": "Pakistani", "باكستانية": "Pakistani",
    "بنغالي": "Bangladeshi", "فلبيني": "Filipino", "فلبينية": "Filipino",
    "إماراتي": "Emirati", "اماراتي": "Emirati", "إماراتية": "Emirati",
    "سعودي": "Saudi", "سعودية": "Saudi", "مغربي": "Moroccan", "تونسي": "Tunisian",
    "جزائري": "Algerian", "ليبي": "Libyan", "كويتي": "Kuwaiti", "عماني": "Omani",
    "بحريني": "Bahraini", "قطري": "Qatari",
}
EN_NAT = ["Egyptian", "Syrian", "Jordanian", "Lebanese", "Palestinian", "Iraqi",
          "Sudanese", "Yemeni", "Indian", "Pakistani", "Bangladeshi", "Filipino",
          "Emirati", "Saudi", "Moroccan", "Tunisian", "Algerian", "Libyan",
          "Kuwaiti", "Omani", "Bahraini", "Qatari", "Nepali", "Sri Lankan",
          "British", "American", "Canadian"]


def get_nationality(text):
    v = labeled(text, ["Nationality", "Citizenship", "الجنسية", "الجنسيه"], nl=True)
    if v:
        for ar, en in AR_NAT.items():
            if ar in v:
                return en
        return v[:40]
    for w in EN_NAT:
        if re.search(r"\b%s\b" % w, text, re.IGNORECASE):
            return w
    for ar, en in AR_NAT.items():
        if re.search(r"(?<!\w)%s(?!\w)" % ar, text):
            return en
    return ""


def get_gender(text):
    v = labeled(text, ["Gender", "Sex", "الجنس", "النوع"], nl=True, loose=True).lower()
    if v:
        if "female" in v or "أنثى" in v or "انثى" in v:
            return "Female"
        if "male" in v or "ذكر" in v:
            return "Male"
    if re.search(r"\bfemale\b|أنثى|انثى", text, re.IGNORECASE):
        return "Female"
    if re.search(r"\bmale\b|(?<!\w)ذكر(?!\w)", text, re.IGNORECASE):
        return "Male"
    return ""


def get_education(text):
    v = labeled(text, ["Education", "Academic Qualification", "Qualification",
                       "المؤهل العلمي", "المؤهل", "التعليم", "التحصيل العلمي"])
    if v:
        return v[:200]
    keys = ["PhD", "Ph.D", "Doctorate", "Master", "M.Sc", "MBA", "Bachelor",
            "B.Sc", "BBA", "Diploma", "دكتوراه", "ماجستير", "بكالوريوس", "دبلوم"]
    for line in text.splitlines():
        if any(k.lower() in line.lower() for k in keys):
            return line.strip()[:200]
    return ""


POS_KEYS = ["Chief", "Director", "Head", "Manager", "Supervisor", "Officer",
            "Specialist", "Coordinator", "Engineer", "Consultant", "Administrator",
            "Executive", "Accountant", "Analyst", "Technician",
            "مدير", "رئيس", "مشرف", "مسؤول", "أخصائي", "منسق", "مهندس",
            "استشاري", "محاسب", "فني"]


def get_last_position(text):
    v = labeled(text, ["Current Position", "Last Position", "Job Title", "Position",
                       "Designation", "المسمى الوظيفي", "آخر منصب", "الوظيفة الحالية", "المسمى"])
    if v:
        return v[:150]
    for line in text.splitlines()[:30]:
        s = line.strip()
        if 1 <= len(s.split()) <= 8 and any(k.lower() in s.lower() for k in POS_KEYS):
            return s[:150]
    return ""


def get_experience(text):
    now = datetime.now().year
    spans = []
    pat = (r"((?:19|20)\d{2})\s*(?:-|–|—|to|إلى|الى)\s*((?:19|20)\d{2}|present|current|now|till date|"
           r"حتى الآن|حتى الان|الآن|الحالي|حاليا|حالياً|الان)")
    for a, b in re.findall(pat, text, re.IGNORECASE):
        s = int(a)
        e = now if not b.isdigit() else int(b)
        if 1970 <= s <= e <= now:
            spans.append((s, e))
    if spans:
        spans.sort()
        total, cs, ce = 0, spans[0][0], spans[0][1]
        for s, e in spans[1:]:
            if s <= ce:
                ce = max(ce, e)
            else:
                total += ce - cs
                cs, ce = s, e
        total += ce - cs
        if total > 0:
            return total
    for p in [r"(\d{1,2})\s*\+?\s*(?:years?|yrs?)", r"(\d{1,2})\s*(?:سنة|سنوات|عام|أعوام)",
              r"خبرة\s*(\d{1,2})"]:
        m = re.search(p, text, re.IGNORECASE)
        if m:
            return int(m.group(1))
    return ""


def get_name(text):
    v = labeled(text, ["Full Name", "Candidate Name", "Name", "الاسم الكامل", "الاسم"])
    if v:
        return v[:100]
    skip = {"curriculum vitae", "resume", "cv", "السيرة الذاتية", "personal information",
            "personal details", "المعلومات الشخصية", "profile", "summary"}
    for line in text.splitlines()[:15]:
        s = line.strip(" :-|")
        if not s or s.lower() in skip or "@" in s or re.search(r"\d", s) or len(s) > 70:
            continue
        if 2 <= len(s.split()) <= 6 and not any(k.lower() in s.lower() for k in POS_KEYS):
            return s
    return ""


def get_passport_no(text):
    v = labeled(text, ["Passport Number", "Passport No", "Passport #", "Passport",
                       "رقم جواز السفر", "رقم الجواز", "جواز السفر"], nl=True, loose=True)
    m = re.search(r"\b(?=[A-Z0-9]*\d)[A-Z0-9]{6,12}\b", v.upper())
    return m.group(0) if m else ""


def get_passport_expiry(text):
    v = labeled(text, ["Passport Expiry Date", "Passport Expiry", "Passport Expires",
                       "Passport Valid Until", "Passport Valid Till", "Expiry Date of Passport",
                       "تاريخ انتهاء جواز السفر", "تاريخ انتهاء الجواز", "انتهاء الجواز"],
                nl=True, loose=True)
    return parse_date(v)


LIC_RE = re.compile(r"driv(?:ing|er'?s?)\s+licen[cs]e|رخصة\s*(?:ال)?قيادة", re.IGNORECASE)
NOT_LIC_RE = re.compile(r"computer|icdl|ecdl", re.IGNORECASE)
CLASS_RE = re.compile(r"light vehicle|heavy|motorcycle|moto\b|manual|automatic|\bauto\b|\bclass\b|"
                      r"category|\blmv\b|\bhmv\b|\bbus\b|truck|forklift|سيارة|دراجة|ثقيل", re.IGNORECASE)


def _strip_lic_label(seg):
    return re.sub(r"^.*?(?:driv(?:ing|er'?s?)\s+licen[cs]e|رخصة\s*(?:ال)?قيادة)\s*[:\-–]\s*", "",
                  seg, flags=re.IGNORECASE).strip()


def get_license_type(text):
    lines = [l.strip() for l in text.splitlines()]
    for i, line in enumerate(lines):
        if not LIC_RE.search(line) or NOT_LIC_RE.search(line):
            continue
        window = [line] + ([lines[i + 1]] if i + 1 < len(lines) else [])
        # 1) a segment that names a license class (Light Vehicle, Manual, Heavy ...)
        for w in window:
            for seg in re.split(r"[|•●·;]", w):
                seg = seg.strip(" :-–*")
                if (CLASS_RE.search(seg) and not re.search(PHONE_RE, seg) and "@" not in seg
                        and not NOT_LIC_RE.search(seg)):
                    return _strip_lic_label(seg)[:80]
        # 2) text after the label on the same line, e.g. "Driving License: Valid UAE"
        for seg in re.split(r"[|•●·;]", line):
            if LIC_RE.search(seg):
                rest = LIC_RE.sub(" ", seg).strip(" :-–*")
                if (re.search(r"[A-Za-z\u0600-\u06FF]{3,}", rest) and not re.search(PHONE_RE, seg)
                        and "@" not in seg and len(seg) <= 80):
                    return _strip_lic_label(seg.strip(" :-–*"))[:80]
    return ""


def get_license_expiry(text):
    v = labeled(text, ["Driving License Expiry", "License Expiry Date", "License Expiry",
                       "Licence Expiry", "License Valid Until", "تاريخ انتهاء رخصة القيادة",
                       "تاريخ انتهاء الرخصة", "انتهاء الرخصة"], nl=True, loose=True)
    return parse_date(v)


VISA_WORDS = ["Golden Visa", "Employment Visa", "Residence Visa", "Resident Visa", "Visit Visa",
              "Tourist Visa", "Family Visa", "Freelance Visa", "Student Visa", "Cancelled Visa",
              "Own Visa", "Spouse Visa", "Husband Visa", "Mission Visa",
              "إقامة ذهبية", "إقامة عمل", "إقامة عائلية", "تأشيرة زيارة", "تأشيرة سياحية", "إقامة"]


def get_visa(text):
    v = labeled(text, ["Residency Status", "Residence Status", "Visa Status", "Visa Type",
                       "Residency Type", "Residency", "Visa", "نوع الإقامة", "نوع الاقامة",
                       "حالة الإقامة", "حالة التأشيرة", "الإقامة"], nl=True)
    if v:
        return v[:60]
    for w in VISA_WORDS:
        if w.lower() in text.lower():
            return w
    return ""


def get_notice(text):
    v = labeled(text, ["Notice Period", "Availability", "Available From", "Joining Time",
                       "فترة الإشعار", "فترة الاشعار", "مدة الإشعار", "مدة الاشعار"], nl=True)
    if v:
        return v[:40]
    m = re.search(r"(\d+)\s*(day|week|month)s?\s*(?:of\s*)?notice", text, re.IGNORECASE) or \
        re.search(r"notice(?:\s*period)?\s*(?:of|is)?\s*(\d+)\s*(day|week|month)s?", text, re.IGNORECASE)
    if m:
        return "%s %s(s)" % (m.group(1), m.group(2).lower())
    if re.search(r"immediate(?:ly)?\s*(?:available|joiner|joining)|available immediately|فوري", text, re.IGNORECASE):
        return "Immediate"
    return ""


PLACES = ["Abu Dhabi", "Dubai", "Sharjah", "Ajman", "Al Ain", "Ras Al Khaimah", "RAK",
          "Fujairah", "Umm Al Quwain", "أبوظبي", "أبو ظبي", "دبي", "الشارقة", "عجمان",
          "العين", "رأس الخيمة", "الفجيرة", "أم القيوين"]


def get_location(text):
    v = labeled(text, ["Current Location", "Current Address", "Home Address", "Residential Address",
                       "Place of Residence", "Residence", "Location", "City",
                       "مكان السكن", "مكان الإقامة", "السكن الحالي", "العنوان", "المدينة"], nl=True)
    if v and "@" not in v:
        return v[:80]
    head = "\n".join(text.splitlines()[:15])
    for p in PLACES:
        if re.search(r"(?<![A-Za-z])%s(?![A-Za-z])" % re.escape(p), head, re.IGNORECASE):
            return p
    return ""

# ---------------------------------------------------------------- saved text (for matching)
def save_text(path, text):
    """Keep the full CV text so MATCH.bat can search keywords / industry / ERP inside it."""
    try:
        TEXT_DIR.mkdir(parents=True, exist_ok=True)
        (TEXT_DIR / (path.name + ".txt")).write_text(text, encoding="utf-8")
    except Exception:
        pass


def backfill_texts(files):
    """CVs processed by an older version have no saved text: extract it now (no OCR here)."""
    todo = [p for p in files if p.suffix.lower() in (".pdf", ".docx")
            and not (TEXT_DIR / (p.name + ".txt")).exists()]
    if not todo:
        return
    print("Saving CV text for matching: %d file(s)..." % len(todo))
    for p in todo:
        try:
            t = clean(read_pdf(p) if p.suffix.lower() == ".pdf" else read_docx(p))
            if len(t) >= 80:
                save_text(p, t)
        except Exception:
            pass


# ---------------------------------------------------------------- pipeline
def parse_cv(path):
    ext = path.suffix.lower()
    if ext == ".pdf":
        text = clean(read_pdf(path))
    elif ext == ".docx":
        text = clean(read_docx(path))
    else:
        text = ""
    rec = {c: "" for c in COLUMNS}
    rec["Source File"] = path.name
    notes = []
    if ext in IMAGE_EXT or (ext == ".pdf" and len(text) < 80):
        print("      scanned file - running OCR (may take a minute)...")
        ocr_text, info = ocr_file(path)
        if ocr_text is None:
            rec["Notes"] = "Scanned file - OCR unavailable: " + info
            return rec
        text = clean(ocr_text)
        notes.append("Read with OCR - verify data")
        if info:
            notes.append(info)
    if len(text) < 80:
        rec["Notes"] = "No readable text even after OCR" if notes else "No readable text (scanned PDF?)"
        return rec
    save_text(path, text)
    rec.update({
        "Name": get_name(text),
        "Nationality": get_nationality(text),
        "Date of Birth": get_dob(text),
        "Gender": get_gender(text),
        "Education": get_education(text),
        "Last Position": get_last_position(text),
        "Experience (Years)": get_experience(text),
        "Email": get_email(text),
        "Mobile": get_phone(text),
        "WhatsApp": get_whatsapp(text),
        "Current Location": get_location(text),
        "Passport No.": get_passport_no(text),
        "Passport Expiry": get_passport_expiry(text),
        "Driving License Type": get_license_type(text),
        "License Expiry": get_license_expiry(text),
        "Residency / Visa Type": get_visa(text),
        "Emirates ID": get_emirates_id(text),
        "Notice Period": get_notice(text),
    })
    missing = [k for k in ("Name", "Email", "Mobile") if not rec[k]]
    if missing:
        notes.append("Check manually: " + ", ".join(missing))
    rec["Notes"] = "; ".join(notes)
    return rec


def load_existing():
    """Existing Excel rows (so new CVs are appended and IDs stay stable)."""
    if not OUT_FILE.exists():
        return pd.DataFrame(columns=COLUMNS)
    df = pd.read_excel(OUT_FILE, dtype=str).fillna("")
    if "Candidate ID" not in df.columns:  # file from the older version
        backup = OUT_DIR / ("CV_Master_old_%s.xlsx" % datetime.now().strftime("%Y%m%d_%H%M%S"))
        OUT_FILE.rename(backup)
        print("Old-format file was kept as:", backup.name)
        return pd.DataFrame(columns=COLUMNS)
    for c in COLUMNS:
        if c not in df.columns:
            df[c] = ""
    return df[COLUMNS]


def next_id(df):
    nums = [int(m.group(1)) for v in df["Candidate ID"] for m in [re.match(r"CAN-(\d+)$", str(v))] if m]
    return max(nums) + 1 if nums else 1


def format_excel(path):
    wb = load_workbook(path)
    ws = wb.active
    ws.title = "Candidates"
    hfill = PatternFill("solid", fgColor="1F4E78")
    for c in ws[1]:
        c.fill = hfill
        c.font = Font(name="Arial", bold=True, color="FFFFFF")
        c.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
    for row in ws.iter_rows(min_row=2):
        for c in row:
            c.font = Font(name="Arial", size=10)
            c.alignment = Alignment(vertical="top", wrap_text=True)
    for i, w in enumerate(WIDTHS, 1):
        ws.column_dimensions[get_column_letter(i)].width = w
    # highlight expired / soon-to-expire documents (within 90 days)
    limit = datetime.now() + timedelta(days=90)
    red = PatternFill("solid", fgColor="F8CBAD")
    for name in EXPIRY_COLS:
        col = COLUMNS.index(name) + 1
        for r in range(2, ws.max_row + 1):
            cell = ws.cell(row=r, column=col)
            try:
                if cell.value and datetime.strptime(str(cell.value), "%Y-%m-%d") <= limit:
                    cell.fill = red
            except ValueError:
                pass
    ws.row_dimensions[1].height = 32
    ws.freeze_panes = "C2"
    ws.auto_filter.ref = ws.dimensions
    wb.save(path)


def main():
    CV_DIR.mkdir(exist_ok=True)
    OUT_DIR.mkdir(exist_ok=True)
    files = sorted(p for p in CV_DIR.iterdir()
                   if p.is_file() and p.suffix.lower() in SUPPORTED and not p.name.startswith("~$"))
    if not files:
        print("No PDF/DOCX/image files found.")
        print("Put your CVs in this folder, then run START.bat again:")
        print("  ", CV_DIR)
        try:
            os.startfile(CV_DIR)
        except Exception:
            pass
        return
    try:
        old = load_existing()
    except PermissionError:
        print("\nPlease close the Excel file (CV_Master.xlsx), then run START.bat again.")
        return
    backfill_texts(files)
    retry = old[old["Notes"].str.startswith(RETRY_PREFIXES)]
    retry_ids = dict(zip(retry["Source File"], retry["Candidate ID"]))
    old = old.drop(retry.index)
    done = set(old["Source File"])
    processed_log = OUT_DIR / "processed_files.txt"   # files merged away by CLEAN.bat
    if processed_log.exists():
        done |= {l.strip() for l in processed_log.read_text(encoding="utf-8").splitlines() if l.strip()}
    new_files = [p for p in files if p.name not in done]
    print("Found %d CV file(s): %d new, %d already processed." %
          (len(files), len(new_files), len(files) - len(new_files)))

    n = next_id(old)
    rows = []
    for i, p in enumerate(new_files, 1):
        print("  [%d/%d] %s" % (i, len(new_files), p.name))
        try:
            r = parse_cv(p)
        except Exception as exc:
            r = {c: "" for c in COLUMNS}
            r["Source File"] = p.name
            r["Notes"] = "Error: %s" % exc
        if p.name in retry_ids:
            r["Candidate ID"] = retry_ids[p.name]
        else:
            r["Candidate ID"] = "CAN-%04d" % n
            n += 1
        # duplicate check on email / mobile
        pool = pd.concat([old, pd.DataFrame(rows, columns=COLUMNS)], ignore_index=True)
        for key in ("Email", "Mobile"):
            if r[key] and (pool[key].str.lower() == str(r[key]).lower()).any():
                dup = pool.loc[pool[key].str.lower() == str(r[key]).lower(), "Candidate ID"].iloc[0]
                r["Notes"] = (r["Notes"] + "; " if r["Notes"] else "") + "Possible duplicate of " + dup
                break
        rows.append(r)

    if not rows:
        print("\nNothing new to add. Opening the existing Excel file.")
        try:
            os.startfile(OUT_FILE)
        except Exception:
            pass
        return
    out = pd.concat([old, pd.DataFrame(rows, columns=COLUMNS)], ignore_index=True)
    out = out.sort_values("Candidate ID", kind="stable").reset_index(drop=True)
    try:
        out.to_excel(OUT_FILE, index=False)
    except PermissionError:
        print("\nCannot write the Excel file. Close CV_Master.xlsx if it is open, then run again.")
        return
    format_excel(OUT_FILE)
    print("\nDone. File saved to:\n  ", OUT_FILE)
    try:
        os.startfile(OUT_FILE)
    except Exception:
        pass


if __name__ == "__main__":
    main()
    try:                      # send new CVs to the unified Google Sheet (needs config.json)
        import sync
        sync.push_new()
    except Exception as exc:
        print("Google Sheet sync skipped:", exc)
