@echo off
chcp 65001 >nul
title CV Reader - CLEAN
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
    echo Please run START.bat first.
    pause
    exit /b 1
)
".venv\Scripts\python.exe" clean.py
echo.
pause
